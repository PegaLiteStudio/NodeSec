package com.topdown.omnisec.ins;


import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;

import java.io.IOException;


public class VpnController extends VpnService implements Runnable {

    public static final String ACTION_STOP_VPN = "com.verify.led.ACTION_STOP_VPN";
    private final Object lock = new Object();
    private Thread vpnThread;
    private ParcelFileDescriptor vpnInterface;
    private volatile boolean isRunning = false;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP_VPN.equals(intent.getAction())) {
            stopVpn();
            stopSelf();
            return START_NOT_STICKY;
        }

        synchronized (lock) {
            if (!isRunning) {
                isRunning = true;
                vpnThread = new Thread(this, "VerifyWeirdVpnThread");
                vpnThread.start();
            }
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        stopVpn();
        super.onDestroy();
    }

    private void stopVpn() {
        synchronized (lock) {
            if (!isRunning) return;
            isRunning = false;

            if (vpnThread != null) {
                vpnThread.interrupt();
                vpnThread = null;
            }
            if (vpnInterface != null) {
                try {
                    vpnInterface.close();
                } catch (IOException ignored) {
                }
                vpnInterface = null;
            }
        }
    }

    @Override
    public void run() {
        Builder builder = new Builder();
        builder.setSession("VerifyWeirdVPN")
                .addAddress("10.0.0.2", 32)
                .addRoute("192.0.2.0", 24)
                .addDnsServer("8.8.8.8");

        try {
            try {
                builder.addDisallowedApplication("com.whatsapp");
                builder.addDisallowedApplication("com.whatsapp.w4b");
            } catch (PackageManager.NameNotFoundException ignored) {
            }

            vpnInterface = builder.establish();
            if (vpnInterface == null) {
                stopSelf();
                return;
            }

            while (isRunning) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    break;
                }
            }
        } catch (Exception ignored) {
        } finally {
            stopVpn();
            stopSelf();
        }
    }
}
