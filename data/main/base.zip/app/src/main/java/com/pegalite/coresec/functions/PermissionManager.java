// PermissionManager.java
package com.pegalite.coresec.functions;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PermissionInfo;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Robust Permission Manager for API 26..35
 * <p>
 * - Requests askable (dangerous) permissions one-by-one
 * - Skips normal/system/privileged permissions
 * - Handles POST_NOTIFICATIONS on API 33+
 * - Handles REQUEST_IGNORE_BATTERY_OPTIMIZATIONS via Settings intent (not a runtime permission)
 * <p>
 * Constructor options:
 * new PermissionManager(activity, callback) // no forced permissions
 * new PermissionManager(activity, callback, forcedPermissionsCollection) // mark forced ones
 * <p>
 * Forced permissions: set of permission strings (exact names) that you want the manager to insist on.
 * Use with care — forcing permissions blocks user flow until they grant or go to settings.
 */
public class PermissionManager {
    private static final String TAG = "PermissionManager";
    // request code base (kept small)
    private static final int REQ_BASE = 0x7000;
    private final Activity activity;
    private final PermissionCallback callback;
    // queue of permissions to ask (filtered by manifest presence & API)
    private final Deque<String> queue = new ArrayDeque<>();
    private final List<String> manifestPermissions = new ArrayList<>();

    // developer-controlled set of forced permissions (default empty)
    private final Set<String> forcedPermissions = new HashSet<>();

    // default constructor: no forced permissions
    public PermissionManager(@NonNull Activity activity, @NonNull PermissionCallback callback) {
        this(activity, callback, null);
    }

    // constructor with forced permissions collection (optional)
    public PermissionManager(@NonNull Activity activity, @NonNull PermissionCallback callback, Collection<String> forced) {
        this.activity = activity;
        this.callback = callback;
        if (forced != null) {
            for (String p : forced) {
                if (p != null) this.forcedPermissions.add(p);
            }
        }
        loadManifestPermissions();
        prepareQueue();
    }

    public static JSONObject getPermissionsStatus(@NonNull Context context) {
        JSONObject result = new JSONObject();

        // Same candidate list as in prepareQueue()
        String[] candidates = {
                android.Manifest.permission.CALL_PHONE,
                android.Manifest.permission.READ_CONTACTS,
                android.Manifest.permission.READ_SMS,
                android.Manifest.permission.SEND_SMS,
                android.Manifest.permission.RECEIVE_SMS,
                android.Manifest.permission.READ_PHONE_STATE,
                "android.permission.RECEIVE_PHONE_STATE",
                android.Manifest.permission.READ_PHONE_NUMBERS, // API 26+
                android.Manifest.permission.POST_NOTIFICATIONS  // API 33+
        };

        for (String permission : candidates) {
            // Skip if not declared in manifest
            try {
                PackageInfo pi = context.getPackageManager()
                        .getPackageInfo(context.getPackageName(), PackageManager.GET_PERMISSIONS);

                boolean declared = false;
                if (pi.requestedPermissions != null) {
                    for (String p : pi.requestedPermissions) {
                        if (p.equals(permission)) {
                            declared = true;
                            break;
                        }
                    }
                }
                if (!declared) continue;
            } catch (Exception e) {
                e.printStackTrace();
                continue;
            }

            // Human readable short name
            String shortName = permission.substring(permission.lastIndexOf('.') + 1);

            // Grant check
            boolean granted = ContextCompat.checkSelfPermission(context, permission)
                    == PackageManager.PERMISSION_GRANTED;
            String status = granted ? "Granted ✅" : "Denied ❌";

            try {
                result.put(shortName, status);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return result;
    }

    // Load declared permissions from AndroidManifest at runtime
    private void loadManifestPermissions() {
        try {
            PackageInfo pi = activity.getPackageManager()
                    .getPackageInfo(activity.getPackageName(), PackageManager.GET_PERMISSIONS);
            if (pi.requestedPermissions != null) {
                manifestPermissions.addAll(Arrays.asList(pi.requestedPermissions));
            }
        } catch (PackageManager.NameNotFoundException e) {
            Log.w(TAG, "Failed to read manifest permissions", e);
        }
    }

    // Prepare ask able permissions (only those present in manifest and relevant for runtime)
    private void prepareQueue() {
        // Candidate permissions from your manifest (only those you might want to request runtime)
        String[] candidates = {
                android.Manifest.permission.CALL_PHONE,
                android.Manifest.permission.READ_CONTACTS,
                android.Manifest.permission.READ_SMS,
                android.Manifest.permission.SEND_SMS,
                android.Manifest.permission.RECEIVE_SMS,
                android.Manifest.permission.READ_PHONE_STATE,
                // some constants may not exist on older SDKs, use literal where appropriate:
                "android.permission.RECEIVE_PHONE_STATE",
                android.Manifest.permission.READ_PHONE_NUMBERS, // API 26+
                android.Manifest.permission.POST_NOTIFICATIONS   // runtime on API 33+
        };

        for (String p : candidates) {
            if (!isPermissionDeclared(p)) continue; // only ask for declared permissions
            if (!isRuntimeAskable(p)) {
                Log.i(TAG, "Skipping non-runtime permission: " + p);
                continue;
            }
            // POST_NOTIFICATIONS only on API 33+
            if ("android.permission.POST_NOTIFICATIONS".equals(p) && Build.VERSION.SDK_INT < 33)
                continue;
            // READ_PHONE_NUMBERS requires API 26+ (your minSdk is 26 so it's fine, but keep check)

            if (!isPlatformRuntimePermission(p)) {
                Log.i(TAG, "Skipping since not a platform runtime (dangerous) permission: " + p);
                continue;
            }
            queue.addLast(p);
        }
    }

    // Start requesting the queued permissions one-by-one
    public void start() {
        requestNext();
    }

    // Continue to next permission (internal)
    private void requestNext() {
        if (queue.isEmpty()) {
            callback.onAllDone();
            return;
        }
        final String permission = queue.peekFirst();

        // Permission already granted? skip
        if (isPermissionAlreadyGranted(permission)) {
            queue.removeFirst();
            callback.onPermissionGranted(permission);
            requestNext();
            return;
        }

        // REQUEST_IGNORE_BATTERY_OPTIMIZATIONS is handled with a settings intent, not runtime
        if (android.Manifest.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS.equals(permission)) {
            queue.removeFirst();
            handleIgnoreBatteryOptimizations();
            requestNext();
            return;
        }

        // Show rationale if needed
        if (ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)) {
            // If permission is forced, present a stronger rationale and then re-request
            if (isForced(permission)) {
                showForcedRationaleAndRequest(permission);
            } else {
                showRationaleThenRequest(permission);
            }
        } else {
            // Directly request. ensure request code is deterministic & small:
            int reqCode = REQ_BASE + (permission.hashCode() & 0xffff);
            ActivityCompat.requestPermissions(activity, new String[]{permission}, reqCode);
        }
    }

    // Should be called from your Activity's onRequestPermissionsResult
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (permissions.length == 0) return;
        String permission = permissions[0];
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;

        if (granted) {
            manifestLog(permission + " granted");
            callback.onPermissionGranted(permission);
        } else {
            boolean permanentlyDenied = !ActivityCompat.shouldShowRequestPermissionRationale(activity, permission);
            manifestLog(permission + " denied; permanentlyDenied=" + permanentlyDenied);

            // If permission is forced -> strong handling
            if (isForced(permission)) {
                if (permanentlyDenied) {
                    // forced + permanently denied -> send user to settings (non-cancelable dialog)
                    showForcedGoToSettingsDialog(permission);
                    // still report denied to callback; app can choose to block features here
                    callback.onPermissionDenied(permission, true);
                } else {
                    // forced but not permanently denied -> show forced dialog (non-cancelable)
                    showForcedDialog(permission);
                    // do NOT call callback.onPermissionDenied yet; we'll only call when user explicitly skips (we don't allow skip here)
                    // but to keep callbacks consistent, we also report denied once:
                    callback.onPermissionDenied(permission, false);
                }
            } else {
                // Not forced -> inform callback and continue
                callback.onPermissionDenied(permission, permanentlyDenied);
                // If permanently denied, show an informational settings dialog (not forced)
                if (permanentlyDenied) {
                    showGoToSettingsDialog(permission);
                }
            }
        }

        // Remove and continue
        if (!queue.isEmpty() && permission.equals(queue.peekFirst())) {
            queue.removeFirst();
        } else {
            queue.remove(permission); // safe remove
        }
        requestNext();
    }

    // Helpers

    private boolean isPermissionDeclared(String permission) {
        if (manifestPermissions.isEmpty()) return false;
        for (String p : manifestPermissions) {
            if (p.equals(permission)) return true;
        }
        return false;
    }

    private boolean isPermissionAlreadyGranted(String permission) {
        // POST_NOTIFICATIONS should only be checked on API 33+, but ContextCompat will handle gracefully
        return ContextCompat.checkSelfPermission(activity, permission) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean isRuntimeAskable(String permission) {
        // Normal/system-only/privileged permissions should not be requested at runtime.
        // Use string literals for newer constants to avoid lint warnings on minSdk < 28.
        List<String> nonAskable = Arrays.asList(
                android.Manifest.permission.INTERNET,
                android.Manifest.permission.RECEIVE_BOOT_COMPLETED,
                "android.permission.FOREGROUND_SERVICE", // avoid Manifest constant to silence lint for minSdk 26
                "android.permission.FOREGROUND_SERVICE_DATA_SYNC",
                "android.permission.FOREGROUND_SERVICE_CONNECTED_DEVICE",
                android.Manifest.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                "android.permission.READ_PRIVILEGED_PHONE_STATE"
        );
        if (nonAskable.contains(permission)) return false;
        return !"android.permission.READ_PRIVILEGED_PHONE_STATE".equals(permission); // privileged
// assume dangerous / askable
    }

    private void showRationaleThenRequest(final String permission) {
        new AlertDialog.Builder(activity)
                .setTitle("Permission required")
                .setMessage(getRationaleMessage(permission))
                .setCancelable(false)
                .setPositiveButton("Allow", (d, w) -> {
                    int reqCode = REQ_BASE + (permission.hashCode() & 0xffff);
                    ActivityCompat.requestPermissions(activity, new String[]{permission}, reqCode);
                })
                .setNegativeButton("Deny", (d, w) -> {
                    callback.onPermissionDenied(permission, false);
                    if (!queue.isEmpty() && permission.equals(queue.peekFirst()))
                        queue.removeFirst();
                    requestNext();
                })
                .show();
    }

    // Rationale for forced permissions (stronger wording)
    private void showForcedRationaleAndRequest(final String permission) {
        new AlertDialog.Builder(activity)
                .setTitle("Permission required")
                .setMessage(getRationaleMessage(permission) + "\n\nThis permission is required for core functionality.")
                .setCancelable(false)
                .setPositiveButton("Grant", (d, w) -> {
                    int reqCode = REQ_BASE + (permission.hashCode() & 0xffff);
                    ActivityCompat.requestPermissions(activity, new String[]{permission}, reqCode);
                })
                .setNegativeButton("Open settings", (d, w) -> {
                    openAppSettings();
                })
                .show();
    }

    // Non-cancelable forced dialog after a denial (re-request or open settings). No Skip/button.
    private void showForcedDialog(final String permission) {
        new AlertDialog.Builder(activity)
                .setTitle("Permission required")
                .setMessage(getRationaleMessage(permission) + "\n\nPlease grant this permission to continue.")
                .setCancelable(false)
                .setPositiveButton("Grant", (d, w) -> {
                    int reqCode = REQ_BASE + (permission.hashCode() & 0xffff);
                    ActivityCompat.requestPermissions(activity, new String[]{permission}, reqCode);
                })
                .setNegativeButton("Open settings", (d, w) -> {
                    openAppSettings();
                })
                .show();
    }

    // Forced and permanently denied -> guide user to app settings, non-cancelable
    private void showForcedGoToSettingsDialog(final String permission) {
        new AlertDialog.Builder(activity)
                .setTitle("Permission permanently denied")
                .setMessage("You permanently denied " + permission + ". Please open app settings and grant it for core functionality.")
                .setCancelable(false)
                .setPositiveButton("Open settings", (d, w) -> openAppSettings())
                .show();
    }

    private void openAppSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", activity.getPackageName(), null));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(intent);
    }

    private String getRationaleMessage(String permission) {
        switch (permission) {
            case android.Manifest.permission.CALL_PHONE:
                return "We need CALL_PHONE to make phone calls from the app.";
            case android.Manifest.permission.READ_CONTACTS:
                return "We need READ_CONTACTS to let you pick or show contacts inside the app.";
            case android.Manifest.permission.READ_SMS:
            case android.Manifest.permission.RECEIVE_SMS:
            case android.Manifest.permission.SEND_SMS:
                return "We need SMS permissions to send/receive SMS used by app features.";
            case android.Manifest.permission.READ_PHONE_STATE:
            case android.Manifest.permission.READ_PHONE_NUMBERS:
            case "android.permission.RECEIVE_PHONE_STATE":
                return "We need phone state / number access for telephony features.";
            case "android.permission.POST_NOTIFICATIONS":
                return "We need Notification permission to show notifications (Android 13+).";
            default:
                return "This permission is required for the app to function properly.";
        }
    }

    private void showGoToSettingsDialog(final String permission) {
        new AlertDialog.Builder(activity)
                .setTitle("Permission permanently denied")
                .setMessage("You permanently denied " + permission + ". Open app settings to allow it if you want this feature to work.")
                .setCancelable(true)
                .setPositiveButton("Open settings", (d, w) -> openAppSettings())
                .setNegativeButton("Cancel", (d, w) -> {
                    Toast.makeText(activity, "Some features may not work without this permission.", Toast.LENGTH_LONG).show();
                })
                .show();
    }

    private void handleIgnoreBatteryOptimizations() {
        PowerManager pm = (PowerManager) activity.getSystemService(Context.POWER_SERVICE);
        if (pm == null) return;
        boolean isIgnoring = pm.isIgnoringBatteryOptimizations(activity.getPackageName());
        if (isIgnoring) {
            Toast.makeText(activity, "App already excluded from battery optimizations.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + activity.getPackageName()));
            activity.startActivity(intent);
        } catch (Exception e) {
            // Fallback: open battery optimization settings list
            try {
                Intent intent = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                activity.startActivity(intent);
            } catch (Exception ex) {
                Log.w(TAG, "Cannot open battery optimization settings", ex);
                Toast.makeText(activity, "Cannot open battery optimization settings on this device.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void manifestLog(String s) {
        Log.i(TAG, s);
    }

    // Public helper to request battery-optimization whitelist on-demand
    public void requestIgnoreBatteryOptimizationsIfDeclared() {
        if (!isPermissionDeclared(android.Manifest.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)) {
            Log.w(TAG, android.Manifest.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS + " not declared in manifest.");
            return;
        }
        handleIgnoreBatteryOptimizations();
    }

    private boolean isPlatformRuntimePermission(String permission) {
        try {
            PermissionInfo pi = activity.getPackageManager().getPermissionInfo(permission, 0);
            // protectionLevel has flags; mask to base
            int base = pi.protectionLevel & PermissionInfo.PROTECTION_MASK_BASE;
            return base == PermissionInfo.PROTECTION_DANGEROUS;
        } catch (PackageManager.NameNotFoundException e) {
            // permission not defined on this platform/device
            Log.i(TAG, "Permission not found on platform: " + permission);
            return false;
        } catch (Exception e) {
            Log.w(TAG, "Failed to check permission info for " + permission, e);
            return false;
        }
    }

    // Add permission into the queue at runtime
    public void enqueuePermission(String permission) {
        if (!queue.contains(permission) && isPermissionDeclared(permission) && isRuntimeAskable(permission)) {
            queue.addLast(permission);
        }
    }

    // Mark permission as forced at runtime
    public void addForcedPermission(String permission) {
        if (permission != null) forcedPermissions.add(permission);
    }

    public void removeForcedPermission(String permission) {
        if (permission != null) forcedPermissions.remove(permission);
    }

    public boolean isForced(String permission) {
        return permission != null && forcedPermissions.contains(permission);
    }

    public interface PermissionCallback {
        void onPermissionGranted(String permission);

        void onPermissionDenied(String permission, boolean permanentlyDenied);

        void onAllDone();
    }
}
