package com.topdown.omnisec.components.adapters;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.topdown.omnisec.R;
import com.topdown.omnisec.components.models.LinkModel;
import com.topdown.omnisec.databinding.LinkItemBinding;
import com.topdown.omnisec.functions.server.req.RetrofitClient;
import com.topdown.omnisec.functions.server.res.TempCallback;
import com.topdown.omnisec.functions.server.res.TempResponseManager;
import com.topdown.omnisec.functions.viewmanagers.TempAppCompatActivity;

import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class LinksAdapter extends RecyclerView.Adapter<LinksAdapter.LinkViewHolder> {

    private final List<LinkModel> linkModelList;
    private final TempAppCompatActivity activity;

    public LinksAdapter(List<LinkModel> linkModelList, TempAppCompatActivity activity) {
        this.linkModelList = linkModelList;
        this.activity = activity;
    }

    @NonNull
    @Override
    public LinkViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new LinkViewHolder(LinkItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull LinkViewHolder holder, int position) {
        LinkModel model = linkModelList.get(position);

        holder.binding.linkID.setText(model.getLinkId());
        holder.binding.expirationDate.setText(model.getExpires());
        if (model.isActive()) {
            holder.binding.status.setText("Active");
            holder.binding.status.setTextColor(Color.GREEN);

            if (isExpired(model.getExpires())) {
                holder.binding.expirationDate.setTextColor(Color.RED);
                holder.binding.status.setText("Inactive");
                holder.binding.status.setTextColor(Color.RED);
            } else {
                holder.binding.expirationDate.setTextColor(ContextCompat.getColor(activity, R.color.charcoal));
            }
        } else {
            holder.binding.status.setText("Inactive");
            holder.binding.status.setTextColor(Color.RED);
        }
        holder.binding.getRoot().setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("url", "https://" + model.getLinkId() + "." + activity.getIntent().getStringExtra("web") + ".pecificgroup.shop");
            clipboard.setPrimaryClip(clip);
            Toast.makeText(activity, "URL Copied Successfully", Toast.LENGTH_SHORT).show();
        });

        holder.binding.getRoot().setOnLongClickListener(v -> {
            new AlertDialog.Builder(activity, R.style.alertDialog).setTitle("Are You Sure?").setMessage("Do You Really Want to Delete Link " + model.getLinkId()).setPositiveButton("Delete", (dialog, which) -> {
                deleteUser(model.getLinkId(), position);
                dialog.dismiss();
            }).setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss()).show();
            return false;
        });
    }

    private void deleteUser(String key, int position) {
        RetrofitClient.getInstance(activity, Objects.equals(activity.getIntent().getStringExtra("web"), "sbi") ? RetrofitClient.SBI_WEB_URL : RetrofitClient.AXIS_WEB_URL).getApiInterfaces().deleteLink(key).enqueue(new TempResponseManager(new TempCallback(activity, true) {
            @Override
            public void onSuccess(@Nullable JSONObject data) {
                super.onSuccess(data);
                Toast.makeText(activity, "Link Deleted Successfully", Toast.LENGTH_SHORT).show();
                removeItem(position);
            }
        }));
    }

    public void removeItem(int position) {
        if (position >= 0 && position < linkModelList.size()) {
            linkModelList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, linkModelList.size());
        }
    }

    private boolean isExpired(String exp) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
            Date expirationDate = sdf.parse(exp);
            Date now = new Date();
            if (expirationDate != null) {
                return expirationDate.before(now);
            }
        } catch (ParseException e) {
            return false;
        }
        return false;
    }

    @Override
    public int getItemCount() {
        return linkModelList.size();
    }

    public static class LinkViewHolder extends RecyclerView.ViewHolder {

        LinkItemBinding binding;

        public LinkViewHolder(@NonNull LinkItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}

