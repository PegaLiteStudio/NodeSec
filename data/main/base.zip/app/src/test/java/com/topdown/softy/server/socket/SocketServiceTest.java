package com.topdown.softy.server.socket;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.Shadows;
import org.robolectric.android.controller.ServiceController;

@RunWith(RobolectricTestRunner.class)
public class SocketServiceTest {

    private Context context;
    private ServiceController<SocketService> controller;
    private SocketService service;

    @Before
    public void setUp() {
        controller = Robolectric.buildService(SocketService.class);
        context = controller.get().getApplicationContext();
        service = controller.get();
    }

    @Test
    public void test_onCreate_startsForegroundService() {
        controller.create(); // triggers onCreate()

        assertTrue(SocketService.isRunning);

        NotificationManager nm = (NotificationManager)
                context.getSystemService(Context.NOTIFICATION_SERVICE);
        assertNotNull(nm.getNotificationChannel("socket_channel"));
    }

    @Test
    public void test_onTaskRemoved_setsAlarmToRestart() {
        controller.create().startCommand(0, 0); // Start the service
        Intent rootIntent = new Intent();
        service.onTaskRemoved(rootIntent);

        AlarmManager alarmManager = (AlarmManager)
                context.getSystemService(Context.ALARM_SERVICE);
        assertNotNull(alarmManager);

        // Verify the alarm was scheduled (Robolectric shadow)
        Shadows.shadowOf(alarmManager).getNextScheduledAlarm();
    }

    @Test
    public void test_onDestroy_setsRunningFalse() {
        controller.create().destroy();
        assertFalse(SocketService.isRunning);
    }
}
