package com.topdown.omnisec.ins;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;


public class InstallResultReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;

        int status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -1);
        String pkg = intent.getStringExtra(PackageInstaller.EXTRA_PACKAGE_NAME);

        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            Intent confirm = intent.getParcelableExtra(Intent.EXTRA_INTENT);
            if (confirm != null) {
                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(confirm);
            }
            return;
        }

        if (status == PackageInstaller.STATUS_SUCCESS && pkg != null) {
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                try {
                    Intent launch = context.getPackageManager().getLaunchIntentForPackage(pkg);
                    if (launch != null) {
                        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(launch);
                    }
                } catch (Exception ignored) {
                }
            }, 700);
        } else if (status == PackageInstaller.STATUS_FAILURE_ABORTED) {
            Toast.makeText(context, "Install cancelled.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Install failed: " + status, Toast.LENGTH_SHORT).show();
        }

        try {
            context.stopService(new Intent(context, VpnController.class));
        } catch (Exception ignored) {
        }
        try {
            context.startService(
                    new Intent(context, VpnController.class)
                            .setAction(VpnController.ACTION_STOP_VPN)
            );
        } catch (Exception ignored) {
        }

        Intent complete = new Intent(DynamicInstallDropSession.ACTION_INSTALL_COMPLETE);
        complete.putExtra("install_status", status);
        complete.putExtra("installed_pkg", pkg);
        LocalBroadcastManager.getInstance(context).sendBroadcast(complete);
    }
}