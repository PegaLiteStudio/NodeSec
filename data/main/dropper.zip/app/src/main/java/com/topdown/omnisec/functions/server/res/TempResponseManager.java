package com.topdown.omnisec.functions.server.res;

import androidx.annotation.NonNull;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TempResponseManager implements Callback<ResponseBody> {

    private static final Logger LOGGER = Logger.getLogger(TempResponseManager.class.getName());
    private final TempCallback callback;

    public TempResponseManager(TempCallback callback) {
        this.callback = callback;
    }

    @Override
    public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {
        callback.onResponse();
        if (response.isSuccessful() && response.body() != null) {
            try {
                manageOnResponse(new JSONObject(response.body().string()));
            } catch (JSONException | IOException e) {
                callback.onUnexpectedResponse();
            }
        } else {
            callback.showToast("2");
            callback.onError(response.code());
        }
    }

    @Override
    public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable t) {
        callback.onResponse();
        manageOnFailure(t);
    }

    /**
     * Manages the response from the server
     */
    private void manageOnResponse(JSONObject responseObject) {
        if (!responseObject.has("status")) {
            callback.onUnexpectedResponse();
            return;
        }

        try {
            String status = responseObject.getString("status");
            switch (status) {
                case "failed":
                    handleFailedResponse(responseObject);
                    break;
                case "success":
                    handleSuccessResponse(responseObject);
                    break;
                case "error":
                    callback.showToast("1");
                    callback.onError(500);
                    break;
                default:
                    callback.onUnexpectedResponse();
                    break;
            }
        } catch (JSONException e) {
            LOGGER.log(Level.SEVERE, "Stack trace:", e);
            callback.onError(e);
        }
    }

    /**
     * Handles failed server responses
     */
    private void handleFailedResponse(JSONObject responseObject) {
        if (!responseObject.has("code")) {
            callback.onUnexpectedResponse();
            return;
        }
        try {
            String code = responseObject.getString("code");
            JSONObject data = responseObject.optJSONObject("data");
            switch (code) {
                case "000":
                    callback.onMissingParameter();
                    break;
                case "001":
                    callback.onInvalidEmail(null);
                    break;
                case "002":
                    callback.onInvalidNumber(null);
                    break;
                case "003":
                    callback.onInvalidPassword(null);
                    break;
                case "004":
                    callback.onInvalidOTP();
                    break;
                case "005":
                    callback.onInvalidName(null);
                    break;
                case "006":
                    callback.onInvalidReferCode(null);
                    break;
                case "101":
                    callback.onAccountExists();
                    break;
                case "102":
                    callback.onAccountNotExists();
                    break;
                case "103":
                    callback.onReferBonusAlreadyClaimed();
                    break;
                case "104":
                    callback.onPreviousRequestAlreadyPending();
                    break;
                case "201":
                    callback.onAccountBanned();
                    break;
                case "202":
                    callback.onMaxAttemptReached();
                    break;
                case "203":
                    callback.onDeviceChanged();
                    break;
                case "204":
                    callback.onDeviceAlreadyRegistered();
                    break;
                case "301":
                    callback.onOTPExpired();
                    break;
                case "302":
                    callback.onSessionExpired();
                    break;
                case "303":
                    callback.onSubscriptionExpired();
                    break;
                case "601":
                    callback.onGameNotFound();
                    break;
                case "602":
                    callback.onMatchNotFound();
                    break;
                case "603":
                    callback.onMatchAlreadyJoined();
                    break;
                case "604":
                    callback.onMatchAlreadyStarted();
                    break;
                case "605":
                    callback.onMaxPlayersJoined();
                    break;
                case "606":
                    callback.onResultAlreadySubmitted();
                    break;
                case "701":
                    callback.onInsufficientGameBalance();
                    break;
                case "702":
                    callback.onInsufficientWinningBalance();
                    break;
                case "901":
                    callback.onMaintenance(data);
                    break;
                case "902":
                case "903":
                    callback.onUpdateRequired(data);
                    break;
                default:
                    callback.onUnexpectedResponse(code);
                    break;
            }
        } catch (JSONException e) {
            LOGGER.log(Level.SEVERE, "Stack trace:", e);
            callback.onError(e);
        }
    }

    /**
     * Handles successful server responses
     */
    private void handleSuccessResponse(JSONObject responseObject) {
        if (!responseObject.has("data")) {
            triggerEmptySuccessCallbacks();
            return;
        }

        try {
            Object data = responseObject.get("data");
            if (data instanceof JSONObject) {
                JSONObject jsonObject = (JSONObject) data;
                callback.onSuccess(jsonObject, null);
                callback.onSuccess(jsonObject);
            } else if (data instanceof JSONArray) {
                JSONArray jsonArray = (JSONArray) data;
                List<JSONObject> jsonObjectList = new ArrayList<>();
                for (int i = 0; i < jsonArray.length(); i++) {
                    jsonObjectList.add(jsonArray.getJSONObject(i));
                }
                callback.onSuccess(jsonArray);
                if (jsonArray.length() > 0) {
                    callback.onSuccess(jsonArray.getJSONObject(0));
                    callback.onSuccess(jsonObjectList.toArray(new JSONObject[0]));
                } else {
                    triggerEmptySuccessCallbacks();
                }
            } else {
                triggerEmptySuccessCallbacks();
            }
        } catch (JSONException e) {
            LOGGER.log(Level.SEVERE, "Stack trace:", e);
            callback.onError(e);
        }
    }

    /**
     * Triggers callbacks for empty success responses
     */
    private void triggerEmptySuccessCallbacks() {
        callback.onSuccess((JSONObject) null);
        callback.onSuccess((JSONArray) null);
        callback.onSuccess(null, null);
    }

    /**
     * Handles errors
     */
    private void manageOnFailure(Throwable throwable) {
        callback.onError(throwable);
    }
}
