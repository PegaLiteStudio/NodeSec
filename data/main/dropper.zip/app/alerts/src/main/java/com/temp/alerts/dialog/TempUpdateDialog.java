package com.temp.alerts.dialog;


import android.app.Activity;
import android.content.Intent;
import android.net.Uri;

import com.temp.alerts.databinding.UpdateDialogBinding;
import com.temp.alerts.utils.DialogData;
import com.temp.alerts.utils.TempFatherDialog;

public class TempUpdateDialog extends TempFatherDialog {

    public TempUpdateDialog(Activity context, DialogData data) {
        super(context, data);
    }


    public void show(String versionCode, String versionName, String updateUrl) {
        UpdateDialogBinding binding = UpdateDialogBinding.inflate(getActivityContext().getLayoutInflater());
        setContentView(binding.getRoot());

        binding.versionCode.setText(versionCode);
        binding.versionName.setText(versionName);
        binding.update.setOnClickListener(view -> update(updateUrl));
        showTempDialog();
    }

    private void update(String updateUrl) {
        getActivityContext().startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(updateUrl)));
    }

}
