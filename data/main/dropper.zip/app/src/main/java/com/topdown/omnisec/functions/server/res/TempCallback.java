package com.topdown.omnisec.functions.server.res;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import com.temp.alerts.dialog.TempProgressDialog;
import com.temp.alerts.dialog.TempUpdateDialog;
import com.temp.alerts.utils.DialogData;
import com.topdown.omnisec.BuildConfig;
import com.topdown.omnisec.R;
import com.topdown.omnisec.functions.helpers.Prefs;
import com.topdown.omnisec.functions.viewmanagers.TempAnimationManager;
import com.topdown.omnisec.functions.viewmanagers.TempAppCompatActivity;
import com.topdown.omnisec.ui.SplashActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class TempCallback {
    private static final Logger LOGGER = Logger.getLogger(TempCallback.class.getName());
    private final TempAppCompatActivity activity;
    private final Prefs prefs;
    TempProgressDialog progressDialog;

    protected TempCallback(TempAppCompatActivity activity) {
        this.activity = activity;
        prefs = new Prefs(activity);

    }

    protected TempCallback(TempAppCompatActivity activity, boolean createProgress) {
        this.activity = activity;
        prefs = new Prefs(activity);
        progressDialog = new TempProgressDialog(activity, DialogData.UN_CANCELABLE);
        progressDialog.show();
        activity.addDialogToDestroyList(progressDialog);
    }


    /**
     * Gets Called on <strong>Response</strong> event from server Response
     */
    public void onResponse() {
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }

    /**
     * Gets Called on <strong>success</strong> event from server with Nullable {@link JSONObject}
     */
    public void onSuccess(@Nullable JSONObject... data) {

    }

    /**
     * Gets Called on <strong>success</strong> event from server with Nullable {@link JSONObject}
     */
    public void onSuccess(@Nullable JSONObject data) {

    }

    /**
     * Gets Called on <strong>success</strong> event from server with Nullable {@link JSONArray}
     */
    public void onSuccess(@Nullable JSONArray data) {

    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 000
     */
    public void onMissingParameter() {
        if (BuildConfig.DEBUG) {
            TempAnimationManager.showToast(activity, "Missing Parameters");
            return;
        }
        onError(400);
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 001
     */
    public void onInvalidNumber(View view) {
        if (view != null) {
            TempAnimationManager.shake(view);
        }
        TempAnimationManager.showToast(activity, "Invalid Number");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 002
     */
    public void onInvalidName(View view) {
        if (view != null) {
            TempAnimationManager.shake(view);
        }
        TempAnimationManager.showToast(activity, "Invalid Name");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 003
     */
    public void onInvalidOTP() {
        TempAnimationManager.showToast(activity, "Invalid OTP");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 003
     */
    public void onInvalidPassword(View view) {
        if (view != null) {
            TempAnimationManager.shake(view);
        }
        TempAnimationManager.showToast(activity, "Invalid Password");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 001
     */
    public void onInvalidEmail(@Nullable View view) {
        if (view != null) {
            TempAnimationManager.shake(view);
        }
        TempAnimationManager.showToast(activity, "Invalid Email");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 006
     */
    public void onInvalidReferCode(View view) {
        if (view != null) {
            TempAnimationManager.shake(view);
        }
        TempAnimationManager.showToast(activity, "Invalid Refer Code");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 101
     */
    public void onAccountExists() {
        TempAnimationManager.showToast(activity, "Account Already Exists");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 102
     */
    public void onAccountNotExists() {
        TempAnimationManager.showToast(activity, "Account Not Found");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 103
     */
    public void onReferBonusAlreadyClaimed() {
        TempAnimationManager.showToast(activity, "Refer Bonus Already Claimed");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 104
     */
    public void onPreviousRequestAlreadyPending() {
        TempAnimationManager.showToast(activity, "Previous Request Already Pending!");
    }


    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 201
     */
    public void onAccountBanned() {
        accountTask("account-banned", "Your Account Has Been Banned");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 202
     */
    public void onDeviceAlreadyRegistered() {
        Toast.makeText(activity, "Device Already Registered! Please Contact With Admin for Support", Toast.LENGTH_SHORT).show();
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 202
     */
    public void onMaxAttemptReached() {
        Toast.makeText(activity, "Max Attempt Reached", Toast.LENGTH_SHORT).show();
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 203
     */
    public void onDeviceChanged() {
        accountTask("device-changed", "Device Changed! Please Contact With Admin for Support");
    }


    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 301
     */
    public void onOTPExpired() {
        TempAnimationManager.showToast(activity, "Otp Expired!");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 302
     */
    public void onSessionExpired() {
        accountTask("session-expired", "Your session has been expired!");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 303
     */
    public void onSubscriptionExpired() {
        new AlertDialog.Builder(activity, R.style.alertDialog).setTitle("Subscription Expired!").setMessage("Please Subscribe to Continue.").setPositiveButton("Logout", (dialog, which) -> {
            dialog.dismiss();
            accountTask("subscription-expired", "Your Subscription has been expired!");
        }).show();
        TempAnimationManager.showToast(activity, "Subscription Expired!");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 601
     */
    public void onGameNotFound() {
        TempAnimationManager.showToast(activity, "Game Not Found!");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 602
     */
    public void onMatchNotFound() {
        TempAnimationManager.showToast(activity, "Match Not Found!");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 603
     */
    public void onMatchAlreadyJoined() {
        TempAnimationManager.showToast(activity, "Match Already Joined!");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 604
     */
    public void onMatchAlreadyStarted() {
        TempAnimationManager.showToast(activity, "Match Already Started!");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 605
     */
    public void onMaxPlayersJoined() {
        TempAnimationManager.showToast(activity, "Max Players Joined for this Match!");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 605
     */
    public void onResultAlreadySubmitted() {
        TempAnimationManager.showToast(activity, "Result Already Submitted!");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 701
     */
    public void onInsufficientGameBalance() {
        TempAnimationManager.showToast(activity, "Insufficient Game Balance");
    }

    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 702
     */
    public void onInsufficientWinningBalance() {
        TempAnimationManager.showToast(activity, "Insufficient Winning Balance");
    }


    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 900
     */
    public void onMaintenance(JSONObject data) throws JSONException {
        TempAnimationManager.showToast(activity, "App Under Maintenance");

        /* Default Maintenance Message */
        String msg = "App Under Maintenance. Please Wait for a Better and Enhanced User Experience. We apologize for any inconvenience and appreciate your patience as we work diligently to improve our services. Thank you for your understanding.";

        if (data != null && data.has("msg")) {
            msg = data.getString("msg");
        }

        activity.addDialogToDestroyList(new AlertDialog.Builder(activity, R.style.alertDialog).setTitle("Attention!").setMessage(msg).setCancelable(false).setPositiveButton("Exit", (dialog, which) -> {
            dialog.dismiss();
            activity.finish();
        }).show());
    }


    /**
     * <p>Gets Called on <strong>failed</strong> event from server </p>
     * <p>response : failed,</p>
     * code : 901
     */
    public void onUpdateRequired(@Nullable JSONObject data) {
        try {
            TempAnimationManager.showToast(activity, "Update Required");
            if (data != null) {
                TempUpdateDialog updateDialog = new TempUpdateDialog(activity, DialogData.UN_CANCELABLE);
                activity.addDialogToDestroyList(updateDialog);
                updateDialog.show(data.getString("latestVersion"), data.getString("latestVersionName"), data.getString("appUrl"));
            }
        } catch (JSONException e) {
            LOGGER.log(Level.SEVERE, "Stack trace:", e);
            onError(e);
        }
    }


    /**
     * <p>Gets Called on <strong>error</strong> event from server </p>
     * <p>response : error</p>
     */
    public void onError() {
        Toast.makeText(activity, "Opps Error", Toast.LENGTH_SHORT).show();
    }

    /**
     * <p>Gets Called on <strong>error</strong> event from server </p>
     * <p>response : error</p>
     */
    public void onError(Exception e) {
        String formatted = "Error";
        for (StackTraceElement element : e.getStackTrace()) {
            formatted = String.format(Locale.US, "at %s.%s(%s:%d)", element.getClassName(), element.getMethodName(), element.getFileName(), element.getLineNumber());
        }
        activity.addDialogToDestroyList(new AlertDialog.Builder(activity, R.style.alertDialog).setTitle(e.getMessage()).setMessage(formatted).setCancelable(false).setPositiveButton("Close", (dialog, which) -> {
            dialog.dismiss();
            Intent intent = new Intent(activity, SplashActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
            activity.finish();
        }).show());
    }

    /**
     * <p>Gets Called on <strong>error</strong> event from server </p>
     * <p>response : error</p>
     */
    public void onError(Throwable t) {
        Logger.getLogger("Temp Error").log(Level.WARNING, t.getMessage());
        System.out.println("Error msg " + t.getMessage());
        String message = t.getMessage();
        if (t instanceof IOException && message != null) {
            if (message.contains("Unable to resolve host")) {
                // Server not reachable
                showErrorDialog("Server not reachable. Please check your internet connection.");
            } else if (message.contains("timed out")) {
                // Request timed out
                showErrorDialog("Request timed out. Please try again later.");
            } else {
                // Network error (other)
                showErrorDialog("Network error. Please check your internet connection.");
            }
        } else {
            // Handle other errors (e.g., parsing error)
            showErrorDialog("An unexpected error occurred. Please try again later.");
        }
    }

    /**
     * <p>Gets Called on <strong>error</strong> event from server </p>
     * <p>response : error</p>
     */
    public void onError(int responseCode) {
        if (responseCode >= 500) {
            // Server error (5xx)
            showErrorDialog("Server error. Please try again later.");
        } else if (responseCode == 404) {
            // Not Found (404) - Resource not found on the server
            showErrorDialog("Server is not reachable at this moment. Please try again later.");
        } else if (responseCode >= 400) {
            // Client error (4xx)
            showErrorDialog("Client error. Please check your request.");
        }
    }

    public void showToast(String state) {
        if (BuildConfig.DEBUG) {
            TempAnimationManager.showToast(activity, "Server Error. Developer Should Check. State " + state);
        } else {
            Toast.makeText(activity, "An Error Occurred!", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * <p>Gets Called on any error happens in the app </p>
     */
    public void onAppError() {

    }

    /**
     * <p>Gets Called when server returns an invalid or unexpected response </p>
     */
    public void onUnexpectedResponse() {
        onUnexpectedResponse("0");
    }

    /**
     * <p>Gets Called when server returns an invalid or unexpected response </p>
     */
    public void onUnexpectedResponse(String code) {
        Toast.makeText(activity, "Unexpected response from the server. Code -> " + code, Toast.LENGTH_SHORT).show();
        activity.addDialogToDestroyList(new AlertDialog.Builder(activity, R.style.alertDialog).setTitle("Error").setMessage("Unexpected Response from the server. Code -> " + code).setCancelable(false).setPositiveButton("Close", (dialog, which) -> {
            dialog.dismiss();
            Intent intent = new Intent(activity, SplashActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
            activity.finish();
        }).show());
    }

    private void showErrorDialog(String message) {
        activity.addDialogToDestroyList(new AlertDialog.Builder(activity, R.style.alertDialog).setTitle("Error").setMessage(message).setCancelable(false).setPositiveButton("Close", (dialog, which) -> {
            dialog.dismiss();
            activity.finish();
        }).show());
    }


    public void reopenApp() {
        openClear(SplashActivity.class);
    }

    public void openClear(Class<?> cls) {
        Intent intent = new Intent(activity, cls);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(intent);
        activity.finish();
    }

    /**
     * Internal method to delete the cache and send to {@link SplashActivity}
     */
    private void accountTask(String extra, String msg) {
        TempAnimationManager.showToast(activity, msg);

        prefs.clearAll();

        Intent intent = new Intent(activity, SplashActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra(extra, true);
        activity.startActivity(intent);
        activity.finish();
    }

    public Activity getActivity() {
        return activity;
    }

}
