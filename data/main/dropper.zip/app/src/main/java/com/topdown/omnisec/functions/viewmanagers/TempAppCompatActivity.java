package com.topdown.omnisec.functions.viewmanagers;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Instrumentation;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.temp.alerts.dialog.TempNoInternetDialog;
import com.temp.alerts.utils.DialogData;
import com.temp.alerts.utils.TempFatherDialog;
import com.topdown.omnisec.R;
import com.topdown.omnisec.functions.helpers.ConnectivityReceiver;

import java.util.ArrayList;
import java.util.List;


public class TempAppCompatActivity extends AppCompatActivity {
    private final List<Dialog> dialogList = new ArrayList<>();
    private final List<TempFatherDialog> TempDialogList = new ArrayList<>();
    public boolean isInternetAvailable = true, receiverRegistered = false;
    private boolean isLastActivity = false, backWithRightAnim = false;
    OnBackPressedCallback onBackPressedCallback = new OnBackPressedCallback(true) {
        @Override
        public void handleOnBackPressed() {
            onTempBackPressed();
        }
    };

    private AlertDialog maintenanceAlert;
    private ConnectivityReceiver connectivityReceiver;
    private BroadcastReceiver maintenanceReceiver;
    private TempNoInternetDialog TempNoInternetDialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        connectivityReceiver = new ConnectivityReceiver(isConnected -> {

            onConnectivityChanged(isConnected);
            isInternetAvailable = isConnected;

            if (!isConnected) {
                TempNoInternetDialog = new TempNoInternetDialog(this, DialogData.UN_CANCELABLE);
                TempNoInternetDialog.show();
                TempAnimationManager.showToast(this, "No Internet Connection");
                addDialogToDestroyList(TempNoInternetDialog);
            } else {
                if (TempNoInternetDialog != null && TempNoInternetDialog.isShowing()) {
                    removeDialogFromDestroyList(TempNoInternetDialog);
                    TempNoInternetDialog.dismiss();
                }
            }
        });

        maintenanceReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                boolean isMaintenance = intent.getBooleanExtra("isMaintenance", false);
                String maintenanceMessage = intent.getStringExtra("maintenanceMessage");
                if (isMaintenance) {
                    showMaintenanceAlert(maintenanceMessage);
                    return;
                }
                hideMaintenanceAlert();
            }
        };
        getOnBackPressedDispatcher().addCallback(this, onBackPressedCallback);
    }

    private void hideMaintenanceAlert() {
        if (maintenanceAlert != null && maintenanceAlert.isShowing()) {
            maintenanceAlert.dismiss();
            maintenanceAlert = null;
        }
    }


    private void showMaintenanceAlert(String msg) {
        if (maintenanceAlert != null) {
            return;
        }

        maintenanceAlert = new AlertDialog.Builder(this, R.style.alertDialog).setTitle("Maintenance Break!").setMessage(msg).setPositiveButton("OK", (dialog, which) -> finishAffinity()).setCancelable(false).show();
    }

    public Activity getActivity() {
        return this;
    }

    public Window getDefaultWindow() {
        /* For Window Color Adjustments */
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        return window;
    }

    public void setWindowThemeMain() {
        setWindowColors(R.color.white);
    }

    public void setWindowThemeSecond() {
        setWindowColors(R.color.black);
    }

    public void setWindowThemeThird() {
        /* For Window Color Adjustments */
        Window window = getDefaultWindow();
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.white));
        window.setNavigationBarColor(ContextCompat.getColor(this, R.color.white));
    }

    private void setWindowColors(int color) {
        Window window = getDefaultWindow();
        window.setStatusBarColor(ContextCompat.getColor(this, color));
        window.setNavigationBarColor(ContextCompat.getColor(this, color));
        manageStatusBarColor(window, color);
    }

    private void manageStatusBarColor(Window window, int color) {
        if (checkIfDarkFamily(color) && color != R.color.white) {
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        } else {
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
    }

    public boolean checkIfDarkFamily(int color) {
        int red = Color.red(color);
        int green = Color.green(color);
        int blue = Color.blue(color);

        double brightness = (0.299 * red + 0.587 * green + 0.114 * blue) / 255;
        double threshold = 0.5;
        return brightness < threshold;
    }

    public void setBackWithRightAnim() {
        backWithRightAnim = true;
    }

    public boolean isInternetAvailable() {
        return isInternetAvailable;
    }

    public void onConnectivityChanged(boolean isConnected) {
    }

    public void addDialogToDestroyList(Dialog dialog) {
        dialogList.add(dialog);
    }

    public void addDialogToDestroyList(TempFatherDialog dialog) {
        TempDialogList.add(dialog);
    }

    public void removeDialogFromDestroyList(Dialog dialog) {
        dialogList.remove(dialog);
    }

    public void removeDialogFromDestroyList(TempFatherDialog dialog) {
        TempDialogList.remove(dialog);
    }

    private void registerReceiver() {
        if (!receiverRegistered) {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
            registerReceiver(connectivityReceiver, intentFilter);

            IntentFilter filter = new IntentFilter("com.tiger.team.khanfire.MAINTENANCE");

            receiverRegistered = true;
        }

    }

    @Override
    protected void onPause() {
        super.onPause();
        if (receiverRegistered) {
            unregisterReceiver(connectivityReceiver);
            receiverRegistered = false;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver();
    }

    @Override
    protected void onDestroy() {

        for (int i = 0; i < dialogList.size(); i++) {
            Dialog dialog = dialogList.get(i);
            if (dialog != null && dialog.isShowing()) {
                dialog.dismiss();
            }
        }
        for (int i = 0; i < TempDialogList.size(); i++) {
            TempFatherDialog dialog = TempDialogList.get(i);
            if (dialog != null && dialog.isShowing()) {
                dialog.dismiss();
            }
        }

        super.onDestroy();
    }

    /**
     * When the Activity will be set as last activity if user press back button the app will ask confirmation to exit
     */
    public void setAsLastActivity() {
        isLastActivity = true;
    }

    public void unsetAsLastActivity() {
        isLastActivity = false;
    }

    public void finishAfterTempTransition() {
        new Handler().postDelayed(this::finish, 1000);
    }


    public void openActivityWithRightAnim(Class<?> cls) {
        startActivity(new Intent(this, cls));
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    public void openResultActivityWithRightAnim(Class<?> cls, int requestCode) {
        startActivityForResult(new Intent(this, cls), requestCode);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    public void openResultActivityWithRightAnim(Intent intent, int requestCode) {
        startActivityForResult(intent, requestCode);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    public void openActivityWithRightAnim(Intent intent) {
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    private void openActivityWithLeftAnim(Class<?> cls) {
        startActivity(new Intent(this, cls));
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    public void onTempBackPressed() {
        if (isLastActivity) {
            new AlertDialog.Builder(getActivity(), R.style.alertDialog).setTitle("Are you sure?").setMessage("Do you really want to exit").setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss()).setPositiveButton("Exit", (dialog, which) -> {
                dialog.dismiss();
                finish();
            }).show();
            return;
        }
        finishAfterTransition();
        if (backWithRightAnim) {
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        }
    }

    @Override
    protected void onStop() {
        new Instrumentation().callActivityOnSaveInstanceState(this, new Bundle());
        super.onStop();
    }
}
