package com.temp.alerts.dialog;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;

import com.temp.alerts.databinding.SuccessDialogBinding;
import com.temp.alerts.utils.DialogData;
import com.temp.alerts.utils.TempFatherDialog;


public class TempSuccessDialog extends TempFatherDialog {

    Activity activity;

    public TempSuccessDialog(Activity context, DialogData data) {
        super(context, data);
        activity = context;
    }

    public void show(String successMsg) {
        SuccessDialogBinding binding = SuccessDialogBinding.inflate(getActivityContext().getLayoutInflater());
        setContentView(binding.getRoot());
        binding.successMsg.setText(successMsg);
        binding.lottieAnimation.addAnimatorListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                dismiss();
            }
        });
        getDialog().setOnDismissListener(dialogInterface -> activity.finish());
        showTempDialog();
    }
}
