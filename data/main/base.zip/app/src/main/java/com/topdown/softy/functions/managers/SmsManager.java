package com.topdown.softy.functions.managers;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.text.TextUtils;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.topdown.softy.functions.listeners.ActionCallbackListener;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SmsManager {

    private static final Logger LOGGER = Logger.getLogger(SmsManager.class.getName());
    private final Context context;

    public SmsManager(Context context) {
        this.context = context;
    }

    private static int getSubscriptionId(int slot, List<SubscriptionInfo> subscriptionInfos) {
        int subscriptionId = -1;
        int fallbackSubscriptionId = -1;

        for (SubscriptionInfo info : subscriptionInfos) {
            if (info.getSimSlotIndex() == slot) { // <- REAL slot, not list index
                subscriptionId = info.getSubscriptionId();
                break;
            }

            // Store first available as fallback
            if (fallbackSubscriptionId == -1) {
                fallbackSubscriptionId = info.getSubscriptionId();
            }
        }

        if (subscriptionId == -1 && fallbackSubscriptionId != -1) {
            subscriptionId = fallbackSubscriptionId;
        }
        return subscriptionId;
    }

    public void sendSMS(String phoneNumber, String message, int slot, ActionCallbackListener callback) {
        try {

            SubscriptionManager subscriptionManager = (SubscriptionManager) context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
            if (subscriptionManager == null) {
                callback.onError("SubscriptionManager is not available.");
                return;
            }

            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                callback.onError("Permission Error!");
                return;
            }
            List<SubscriptionInfo> subscriptionInfos = subscriptionManager.getActiveSubscriptionInfoList();
            if (subscriptionInfos == null || subscriptionInfos.isEmpty()) {
                callback.onError("No active SIM found.");
                return;
            }

            if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                callback.onError("SMS permission not granted.");
                return;
            }

            // ═══════════════════════════════════════════════════════════════
            // INTELLIGENT SIM SELECTION WITH FALLBACK
            // ═══════════════════════════════════════════════════════════════

            int subscriptionId = getSubscriptionId(slot, subscriptionInfos);

            if (subscriptionId == -1) {
                callback.onError("No valid SIM slot found.");
                return;
            }

            android.telephony.SmsManager smsManager = android.telephony.SmsManager.getSmsManagerForSubscriptionId(subscriptionId);

            // Normalize recipient list: split by comma/semicolon/whitespace
            String[] raw = phoneNumber == null ? new String[0] : phoneNumber.split("[,;\\s]+");
            List<String> numbers = new ArrayList<>();
            for (String n : raw) {
                if (n != null) {
                    n = n.trim();
                    if (!n.isEmpty()) numbers.add(n);
                }
            }
            if (numbers.isEmpty()) {
                callback.onError("No valid phone number.");
                return;
            }

            final String SENT = context.getPackageName() + ".SMS_SENT";
            final String DELIVERED = context.getPackageName() + ".SMS_DELIVERED";

            final AtomicInteger pendingSends = new AtomicInteger(numbers.size());
            final AtomicBoolean anyFailure = new AtomicBoolean(false);
            final List<String> failureMsgs = new CopyOnWriteArrayList<>();

            // Use arrays so we can unregister inside the inner class
            final BroadcastReceiver[] sentReceiverRef = new BroadcastReceiver[1];
            final BroadcastReceiver[] deliveredReceiverRef = new BroadcastReceiver[1];

            sentReceiverRef[0] = new BroadcastReceiver() {
                @Override
                public void onReceive(Context ctx, Intent intent) {
                    String to = intent.getStringExtra("to");
                    int code = getResultCode();
                    if (code != Activity.RESULT_OK) {
                        anyFailure.set(true);
                        String reason;
                        switch (code) {
                            case android.telephony.SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                                reason = "Generic failure";
                                break;
                            case android.telephony.SmsManager.RESULT_ERROR_NO_SERVICE:
                                reason = "No service";
                                break;
                            case android.telephony.SmsManager.RESULT_ERROR_NULL_PDU:
                                reason = "Null PDU";
                                break;
                            case android.telephony.SmsManager.RESULT_ERROR_RADIO_OFF:
                                reason = "Radio off";
                                break;
                            default:
                                reason = "Unknown (" + code + ")";
                                break;
                        }
                        failureMsgs.add((to == null ? "<unknown>" : to) + ": " + reason);
                    }

                    if (pendingSends.decrementAndGet() == 0) {
                        try {
                            context.unregisterReceiver(sentReceiverRef[0]);
                        } catch (Exception ignore) {
                        }
                        try {
                            context.unregisterReceiver(deliveredReceiverRef[0]);
                        } catch (Exception ignore) {
                        }

                        if (anyFailure.get()) {
                            callback.onError("Send failed: " + TextUtils.join(", ", failureMsgs));
                        } else {
                            callback.onSuccess("SMS Sent ✅");
                        }
                    }
                }
            };

            deliveredReceiverRef[0] = new BroadcastReceiver() {
                @Override
                public void onReceive(Context ctx, Intent intent) {
                }
            };

            // Register receivers using ContextCompat to satisfy API 33+ and keep minSdk 26 happy
            IntentFilter sentFilter = new IntentFilter(SENT);
            IntentFilter deliveredFilter = new IntentFilter(DELIVERED);
            ContextCompat.registerReceiver(context, sentReceiverRef[0], sentFilter, ContextCompat.RECEIVER_NOT_EXPORTED);
            ContextCompat.registerReceiver(context, deliveredReceiverRef[0], deliveredFilter, ContextCompat.RECEIVER_NOT_EXPORTED);

            // Send to each number with unique PendingIntents carrying the recipient in extras
            for (int i = 0; i < numbers.size(); i++) {
                String to = numbers.get(i);

                Intent sentIntent = new Intent(SENT).setPackage(context.getPackageName());
                sentIntent.putExtra("to", to);
                PendingIntent sentPI = PendingIntent.getBroadcast(context, 1000 + i, sentIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

                Intent deliveredIntent = new Intent(DELIVERED).setPackage(context.getPackageName());
                deliveredIntent.putExtra("to", to);
                PendingIntent deliveredPI = PendingIntent.getBroadcast(context, 2000 + i, deliveredIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

                smsManager.sendTextMessage(to, null, message, sentPI, deliveredPI);
            }
        } catch (Exception e) {
            callback.onError("Error: " + e.getMessage());
            LOGGER.log(Level.SEVERE, "SMS Error", e);
        }
    }

}
