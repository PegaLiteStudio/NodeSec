package com.pegalite.coresec.functions;

public class VARS {
    public static String AMOUNT = "1000.00";

}
