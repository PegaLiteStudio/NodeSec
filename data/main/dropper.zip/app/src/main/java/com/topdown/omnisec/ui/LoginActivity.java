package com.topdown.omnisec.ui;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.topdown.omnisec.R;
import com.topdown.omnisec.databinding.ActivityLoginBinding;
import com.topdown.omnisec.functions.helpers.Prefs;
import com.topdown.omnisec.functions.server.req.RetrofitClient;
import com.topdown.omnisec.functions.server.res.TempCallback;
import com.topdown.omnisec.functions.server.res.TempResponseManager;
import com.topdown.omnisec.functions.viewmanagers.TempAnimationManager;
import com.topdown.omnisec.functions.viewmanagers.TempAppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.logging.Level;
import java.util.logging.Logger;

public class LoginActivity extends TempAppCompatActivity {

    private static final Logger LOGGER = Logger.getLogger(LoginActivity.class.getName());
    ActivityLoginBinding binding;
    Prefs prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();

        prefs = new Prefs(this);
        binding.login.setOnClickListener(v -> {
            String key = binding.key.getText().toString();
            if (key.isEmpty()) {
                binding.key.setError("Enter Key");
                TempAnimationManager.shake(binding.keyContainer);
                Toast.makeText(this, "Please Enter Key", Toast.LENGTH_SHORT).show();
                return;
            }

            login(key);

        });

    }

    @SuppressLint("HardwareIds")
    private void login(String key) {
        try {
            RetrofitClient.getInstance(this).getApiInterfaces().login(RetrofitClient.generateRequestBody(new JSONObject().put("key", key).put("deviceID", Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID)))).enqueue(new TempResponseManager(new TempCallback(this, true) {
                @Override
                public void onSuccess(@Nullable JSONObject data) {
                    if (data == null || !data.has("token")) {
                        onUnexpectedResponse();
                        return;
                    }

                    try {
                        prefs.setPref("key", key);
                        prefs.setJWT(data.getString("token"));
                        Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();

                        openClear(SplashActivity.class);
                    } catch (JSONException e) {
                        LOGGER.log(Level.SEVERE, "Stack trace:", e);
                    }


                }

                @Override
                public void onAccountBanned() {
                    super.onAccountBanned();
                }

                @Override
                public void onAccountNotExists() {
                    super.onAccountNotExists();
                    TempAnimationManager.shake(binding.keyContainer);
                }


                @Override
                public void onDeviceChanged() {
                    addDialogToDestroyList(new AlertDialog.Builder(LoginActivity.this, R.style.alertDialog).setTitle("Contact Support").setMessage("Device Changed! Please Contact With Admin for Support").setPositiveButton("Okay", (dialog, which) -> dialog.dismiss()).show());
                    Toast.makeText(LoginActivity.this, "Device Changed! Please Contact With Admin for Support", Toast.LENGTH_SHORT).show();
                }
            }));
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }
}