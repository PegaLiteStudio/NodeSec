package com.topdown.softy.server.socket;

import com.topdown.softy.server.req.RetrofitClient;

import java.net.URISyntaxException;

import io.socket.client.IO;
import io.socket.client.Socket;

public class SocketServer {

    private static Socket socket;

    public static void init(String deviceID) {
        IO.Options options = new IO.Options();
        options.reconnection = true;
        options.reconnectionAttempts = Integer.MAX_VALUE;
        options.reconnectionDelay = 1000;
        options.timeout = 60000; // 60 seconds

        options.query = "deviceID=" + deviceID;
        try {
            socket = IO.socket(RetrofitClient.BASE_URL, options);
            socket.connect();
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }

    }

    public static Socket getSocket() {
        return socket;
    }
}
