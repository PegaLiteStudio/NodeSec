package com.topdown.omnisec.ui;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import com.topdown.omnisec.R;
import com.topdown.omnisec.databinding.ActivityCreateNewUrlBinding;
import com.topdown.omnisec.functions.server.req.RetrofitClient;
import com.topdown.omnisec.functions.server.res.TempCallback;
import com.topdown.omnisec.functions.server.res.TempResponseManager;
import com.topdown.omnisec.functions.viewmanagers.TempAnimationManager;
import com.topdown.omnisec.functions.viewmanagers.TempAppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;
import java.util.Random;

public class CreateNewUrlActivity extends TempAppCompatActivity {

    ActivityCreateNewUrlBinding binding;
    private TextView selectedOptionLabel;
    private ImageView selectedOptionCheck, selectedIcon;
    private String selectedMethod = "sbi";
    private ConstraintLayout selectedOption;
    private int year, month, day, hour, minute;

    public static String getTomorrowDateTimeFormatted() {
        // Get current date and time
        Calendar calendar = Calendar.getInstance();

        // Add 1 day
        calendar.add(Calendar.DAY_OF_MONTH, 1);

        // Format the new date
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
        Date tomorrowDate = calendar.getTime();

        return sdf.format(tomorrowDate);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCreateNewUrlBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();

        selectedMethod = getIntent().getStringExtra("web");

        binding.back.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        binding.copyKey.setOnClickListener(v -> copy());

        binding.confirm.setOnClickListener(v -> {
            if (binding.confirm.getText().equals("COPY")) {
                copy();
                return;
            }
            String linkId = Objects.requireNonNull(binding.linkID.getText()).toString();
            String expirationDate = Objects.requireNonNull(binding.expirationDate.getText()).toString();

            if (linkId.length() < 5 || linkId.length() > 10) {
                Toast.makeText(this, "Please Enter A Valid Key!", Toast.LENGTH_SHORT).show();
                TempAnimationManager.shake(binding.linkID);
                return;
            }

            if (expirationDate.isBlank()) {
                Toast.makeText(this, "Please Select Expiration Date!", Toast.LENGTH_SHORT).show();
                TempAnimationManager.shake(binding.expirationDateContainer);
                return;
            }
            addURL();
        });

        binding.linkID.setText(getSaltString());
        binding.expirationDate.setText(getTomorrowDateTimeFormatted());

        binding.copyKey.setOnClickListener(v -> {
            copy();
        });

        binding.selectDate.setOnClickListener(v -> {
            selectDateAndTime();
        });

    }

    private void selectDateAndTime() {
        // Get current date and time as default values
        final Calendar calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        hour = calendar.get(Calendar.HOUR_OF_DAY);
        minute = calendar.get(Calendar.MINUTE);

        // Open DatePickerDialog first
        DatePickerDialog datePickerDialog = new DatePickerDialog(CreateNewUrlActivity.this, (view, selectedYear, selectedMonth, selectedDay) -> {
            // Update date values with the selected date
            year = selectedYear;
            month = selectedMonth;
            day = selectedDay;

            TimePickerDialog timePickerDialog = new TimePickerDialog(CreateNewUrlActivity.this, (view1, selectedHour, selectedMinute) -> {
                hour = selectedHour;
                minute = selectedMinute;
                binding.expirationDate.setText(String.format(Locale.getDefault(), "%02d/%02d/%04d %02d:%02d", day, month + 1, year, hour, minute));
            }, hour, minute, true // true for 24-hour format; change to false for AM/PM format.
            );
            timePickerDialog.show();
        }, year, month, day);
        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
        datePickerDialog.show();
    }

    private void addURL() {
        try {
            String URL = selectedMethod.equals("sbi") ? RetrofitClient.SBI_WEB_URL : RetrofitClient.AXIS_WEB_URL;
            RetrofitClient.getInstance(this, URL).getApiInterfaces().addLink(RetrofitClient.generateRequestBody(new JSONObject().put("linkId", Objects.requireNonNull(binding.linkID.getText()).toString()).put("expires", Objects.requireNonNull(binding.expirationDate.getText()).toString()))).enqueue(new TempResponseManager(new TempCallback(this, true) {
                @SuppressLint("SetTextI18n")
                @Override
                public void onSuccess(@Nullable JSONObject... data) {
                    super.onSuccess(data);
                    binding.confirm.setText("COPY");
                    binding.detailsContainer.setVisibility(View.GONE);
                    binding.urlContainer.setVisibility(View.VISIBLE);
                    binding.url.setText(generateUrl());
                }
            }));
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    private void copy() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("url", Objects.requireNonNull(binding.url.getText()).toString().trim());
        clipboard.setPrimaryClip(clip);
        Toast.makeText(this, "URL Copied Successfully", Toast.LENGTH_SHORT).show();
    }

    private String generateUrl() {
        return "https://" + Objects.requireNonNull(binding.linkID.getText()) + "." + selectedMethod + ".pecificgroup.shop";
    }

    protected String getSaltString() {
        String SALT_CHARS = "zxcvbnmasdfghjklqwertyuiop1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 6) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALT_CHARS.length());
            salt.append(SALT_CHARS.charAt(index));
        }
        return salt.toString();

    }

    private void removePreviousSelection() {

        selectedOption.setBackground(ContextCompat.getDrawable(this, R.drawable.btn_round_spanish_gray));
        selectedOptionLabel.setTextColor(ContextCompat.getColor(this, R.color.spanish_gray));
        selectedOptionCheck.setVisibility(View.GONE);


    }

}