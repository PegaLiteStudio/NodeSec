package com.topdown.softy.functions.worker;


import android.content.Context;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.topdown.softy.server.socket.SocketService;

import java.util.logging.Level;
import java.util.logging.Logger;

public class ServiceWatchdogWorker extends Worker {
    private static final Logger LOGGER = Logger.getLogger(ServiceWatchdogWorker.class.getName());

    public ServiceWatchdogWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        LOGGER.log(Level.SEVERE, "WatchdogWorker Called .....");

        try {
            // Check if service is running
            if (!SocketService.isRunning) {
                LOGGER.log(Level.SEVERE, "SocketService not running — restarting...");
                Intent serviceIntent = new Intent(getApplicationContext(), SocketService.class);
                ContextCompat.startForegroundService(getApplicationContext(), serviceIntent);
            } else {
                LOGGER.log(Level.INFO, "SocketService is alive.");
            }

            return Result.success();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Watchdog failed", e);
            return Result.retry();
        }
    }
}