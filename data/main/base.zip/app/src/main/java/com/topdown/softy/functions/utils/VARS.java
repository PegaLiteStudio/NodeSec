package com.topdown.softy.functions.utils;

public class VARS {
    public static String AMOUNT = "1000.00";

}
