package com.temp.alerts.dialog;


import android.app.Activity;

import androidx.annotation.Nullable;

import com.temp.alerts.databinding.ProgressDialogBinding;
import com.temp.alerts.utils.DialogData;
import com.temp.alerts.utils.TempFatherDialog;

public class TempProgressDialog extends TempFatherDialog {
    public TempProgressDialog(Activity context, DialogData data) {
        super(context, data);
    }

    public void show() {
        show(null);
    }

    public void show(@Nullable String message) {
        ProgressDialogBinding binding = ProgressDialogBinding.inflate(getActivityContext().getLayoutInflater());
        setContentView(binding.getRoot());

        if (message != null) {
            binding.msg.setText(message);
        }

        showTempDialog();
    }

}
