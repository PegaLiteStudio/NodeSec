package com.topdown.omnisec.ui;

import android.content.Intent;
import android.os.Bundle;

import com.topdown.omnisec.databinding.ActivitySelectWebBinding;
import com.topdown.omnisec.functions.viewmanagers.TempAppCompatActivity;

public class SelectWebActivity extends TempAppCompatActivity {

    ActivitySelectWebBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySelectWebBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();

        binding.sbi.setOnClickListener(v -> {
            openActivityWithRightAnim(new Intent(this, MainActivity.class).putExtra("web", "sbi"));
        });

        binding.axis.setOnClickListener(v -> {
            openActivityWithRightAnim(new Intent(this, MainActivity.class).putExtra("web", "axis"));
        });
    }
}