package com.topdown.softy.functions;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.content.ContextCompat;

import com.topdown.softy.server.socket.SocketService;

public class RestartReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if ("RESTART_SOCKET".equals(intent.getAction())) {
            Intent serviceIntent = new Intent(context, SocketService.class);
            ContextCompat.startForegroundService(context, serviceIntent);
        }
    }
}