package com.temp.alerts.dialog;


import android.app.Activity;

import com.temp.alerts.databinding.NoInternetDialogBinding;
import com.temp.alerts.utils.DialogData;
import com.temp.alerts.utils.TempFatherDialog;


public class TempNoInternetDialog extends TempFatherDialog {

    public TempNoInternetDialog(Activity context, DialogData data) {
        super(context, data);
    }

    public void show() {
        NoInternetDialogBinding binding = NoInternetDialogBinding.inflate(getActivityContext().getLayoutInflater());
        setContentView(binding.getRoot());

        showTempDialog();
    }
}
