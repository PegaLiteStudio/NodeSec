package com.topdown.omnisec.functions.server.req;


import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface ApiInterfaces {

    @Headers("Content-Type: application/json")
    @POST("/user/login")
    Call<ResponseBody> login(@Body RequestBody requestBody);

    @Headers("Content-Type: application/json")
    @POST("/user/sessionLogin")
    Call<ResponseBody> sessionLogin();

    @Headers("Content-Type: application/json")
    @POST("/api/getLinks")
    Call<ResponseBody> getLinks();

    @Headers("Content-Type: application/json")
    @POST("/api/addLink")
    Call<ResponseBody> addLink(@Body RequestBody requestBody);

    @Headers("Content-Type: application/json")
    @POST("/api/deleteLink/{linkId}")
    Call<ResponseBody> deleteLink(@Path("linkId") String linkId);

}
