package com.topdown.omnisec.ui;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;

import com.topdown.omnisec.databinding.ActivitySplashBinding;
import com.topdown.omnisec.functions.helpers.Prefs;
import com.topdown.omnisec.functions.server.req.RetrofitClient;
import com.topdown.omnisec.functions.server.res.TempCallback;
import com.topdown.omnisec.functions.server.res.TempResponseManager;
import com.topdown.omnisec.functions.viewmanagers.TempAppCompatActivity;

import org.json.JSONObject;

public class SplashActivity extends TempAppCompatActivity {

    ActivitySplashBinding binding;
    Prefs prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySplashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        prefs = new Prefs(this);

        sessionLogin();

        setWindowThemeSecond();

    }

    private void sessionLogin() {

        if (!prefs.checkLogin()) {
            openActivityWithRightAnim(LoginActivity.class);
            finish();
            return;
        }

        RetrofitClient.getInstance(SplashActivity.this).getApiInterfaces().sessionLogin().enqueue(new TempResponseManager(new TempCallback(SplashActivity.this, true) {
            @Override
            public void onResponse() {
                super.onResponse();
            }

            @Override
            public void onSuccess(@Nullable JSONObject data) {
                openActivityWithRightAnim(SelectWebActivity.class);
                finish();
            }

            @Override
            public void onInvalidPassword(View view) {
                onSessionExpired();
            }

            @Override
            public void onAccountNotExists() {
                onSessionExpired();
            }


        }));

    }
}