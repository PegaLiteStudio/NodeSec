plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.topdown.omnisec"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.topdown.omnisec"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    signingConfigs {
        var path = "C:\\Users\\sahil\\OneDrive\\Documents\\JKS\\5gonly.jks";
        var storePassword = "786999";
        var keyAlias = "key0";
        var keyPassword = "786999";
        create("release") {
            storeFile =
                file(path)
            this.storePassword = storePassword
            this.keyAlias = keyAlias
            this.keyPassword = keyPassword
            enableV1Signing = true
            enableV2Signing = true
            enableV3Signing = true
            enableV4Signing = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    buildFeatures {
        viewBinding = true
        buildConfig = true

    }
}

dependencies {

    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)

    // For Server Connection
    implementation(libs.retrofit)
    implementation(libs.converter.gson)

    // For Realtime Connection
    implementation(libs.socket.io.client)

    /* YOYO For Animation */
    implementation(project(":app:yoyo"))

    /*For Window Alerts*/
    implementation(project(":app:alerts"))

    implementation(libs.localbroadcastmanager)

    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
}