package com.topdown.omnisec.components.models;

public class LinkModel {
    String linkId, expires;
    boolean active;

    public LinkModel() {
    }

    public String getLinkId() {
        return linkId;
    }

    public void setLinkId(String linkId) {
        this.linkId = linkId;
    }

    public String getExpires() {
        return expires;
    }


    public void setExpires(String expires) {
        this.expires = expires;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
