package com.topdown.softy.functions.listeners;

public interface ActionCallbackListener {
    void onSuccess(String message);

    void onError(String message);

}
