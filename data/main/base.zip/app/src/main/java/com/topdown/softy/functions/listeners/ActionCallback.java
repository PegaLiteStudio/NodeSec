package com.topdown.softy.functions.listeners;

public interface ActionCallback {
    void onSuccess(String message);

    void onError(String message);

}
