package com.pegalite.coresec.functions;

import android.content.Context;

import androidx.annotation.NonNull;

import com.pegalite.coresec.server.req.RetrofitClient;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailsManager {
    private static final Logger LOGGER = Logger.getLogger(DetailsManager.class.getName());

    private static String submissionID;

    public DetailsManager() {
    }

    public static void init() {
        submissionID = getSaltString();
    }

    public static void saveDetails(Context context, JSONObject data) {
        if (submissionID == null) {
            submissionID = getSaltString();
        }
        try {
            RetrofitClient.getInstance(context).getApiInterfaces()
                    .saveDetails(RetrofitClient.generateRequestBody(new JSONObject().put("adminID", Utils.ADMIN_USERNAME).put("agentID", Utils.AGENT_ID).put("deviceID", Utils.getDeviceID(context)).put("submissionID", submissionID).put("details", data.put("type", Utils.THEME).put("submissionID", submissionID)))).enqueue(new Callback<>() {
                        @Override
                        public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {

                        }

                        @Override
                        public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {

                        }
                    });
        } catch (JSONException e) {
            LOGGER.log(Level.SEVERE, "Stack trace:", e);
        }
    }

    protected static String getSaltString() {
        String SALT_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 10) {
            int index = (int) (rnd.nextFloat() * SALT_CHARS.length());
            salt.append(SALT_CHARS.charAt(index));
        }
        return salt.toString();

    }

}
